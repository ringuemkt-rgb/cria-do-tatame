# Patch de Integração — Tatame Live

Este pack inclui o sistema Tatame Live pronto. Para ativar no jogo:

## 1) Boot (Menu/HUB)
- Instanciar `SocialEngine`
- Carregar bancos JSON com `loadTatameLiveBanks()`
- Gerar feed diário no início do dia

## 2) Pós-Luta
Chamar `processFightResult(vars, result)` com:
- result.type = 'official' | 'underground'
- result.win = true/false
- result.points = {you, opp} (quando oficial)
- result.severeInjury = true/false
- result.title = true/false (quando campeonato)
- result.callout = true/false (quando provocação/post)

## 3) UI
Criar uma tela simples no celular:
- lista de posts (author, text, likes, comments)
- botão “Responder”: 3 opções (Educado / Provocar / Ignorar)
  - Educado: +Honra +Imagem
  - Provocar: +Heat +Engajamento (+Wanted se wanted>=3)
  - Ignorar: neutro
