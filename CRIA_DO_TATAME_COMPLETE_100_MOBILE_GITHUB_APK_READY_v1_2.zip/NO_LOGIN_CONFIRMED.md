# Login removido
Este pack não inclui sistema de login/autenticação.
O jogo inicia direto no menu/jogo e o progresso é salvo localmente (offline).
