# CRIA DO TATAME — v2 Mobile Ready (No-Login)

## Objetivo
Este pack corrige o v2.0 para **rodar no celular** com:
- Touch HUD (D‑Pad + A/B/C/D + OK/VOLTA)
- Scale FIT + autocenter
- Offline-first (Phaser local via vendor; script baixa no build)
- Service Worker só no PWA (não no Capacitor)
- Sem tela de login (boot direto no jogo/menu)

## Passo a passo (Anygen/Manus)
1) **Baixar Phaser local** (offline-ready):
   - `node tools/build_agent/fetch_phaser.js`
2) Verificar checklist:
   - `node tools/build_agent/build_verify.js`
3) (Opcional) Rodar servidor local:
   - `npx http-server web -p 8080`
4) Gerar APK com Capacitor (recomendado):
   - `npm init -y`
   - `npm i -D @capacitor/core @capacitor/cli`
   - `npx cap init "CRIA DO TATAME" "com.criadotatame.app" --web-dir web`
   - `npx cap add android`
   - `npx cap sync android`
   - `npx cap open android` (ou build via gradle)
   - Android Studio: Build > Build APK(s)

## Mapeamento de botões (mobile)
- D‑Pad: mover
- OK: ENTER (interagir) / SPACE (timing quando aplicável)
- VOLTA: ESC (menu)
- A/B/C/D: ações 1–4 nas lutas
- C no treino: troca técnica (equiv. tecla T)
