// tools/build_agent/fetch_phaser.js
// Baixa Phaser 3.80.1 minificado para web/vendor/phaser.min.js (offline-ready).
// Requer internet APENAS no momento do build.
import https from "https";
import fs from "fs";
import path from "path";

const URL = "https://cdn.jsdelivr.net/npm/phaser@3.80.1/dist/phaser.min.js";
const out = path.resolve("web/vendor/phaser.min.js");

fs.mkdirSync(path.dirname(out), { recursive: true });

console.log("[fetch_phaser] downloading:", URL);
https.get(URL, (res) => {
  if (res.statusCode !== 200) {
    console.error("[fetch_phaser] HTTP", res.statusCode);
    process.exit(2);
  }
  const file = fs.createWriteStream(out);
  res.pipe(file);
  file.on("finish", () => {
    file.close();
    const sz = fs.statSync(out).size;
    console.log("[fetch_phaser] saved:", out, "bytes:", sz);
    if (sz < 1000000) {
      console.warn("[fetch_phaser] WARNING: file seems too small; check URL or network.");
    }
  });
}).on("error", (e) => {
  console.error("[fetch_phaser] error:", e);
  process.exit(3);
});
