// tools/build_agent/pack_release.js
import fs from "fs";
import path from "path";
import { execSync } from "child_process";

const out = "CRIA_DO_TATAME_V2_MOBILE_READY_NOLOGIN_BUILD_READY.zip";
if(fs.existsSync(out)) fs.rmSync(out);

console.log("[pack] zipping web + tools + docs ->", out);
execSync(`zip -r ${out} web tools README_BUILD.md QA_CHECKLIST.md VERSION_NOTES.md`, { stdio:"inherit" });
