// tools/build_agent/build_verify.js
import fs from "fs";
import path from "path";

const checklist = JSON.parse(fs.readFileSync(path.resolve("tools/build_agent/checklist_master.json"),"utf8"));
let ok = true;

function exists(p){ return fs.existsSync(path.resolve(p)); }

console.log("== Build Verify ==");
for(const f of checklist.required_files){
  const ex = exists(f);
  console.log(ex ? "✅" : "❌", f);
  if(!ex) ok = false;
}
console.log("\n== Recommended ==");
for(const f of checklist.optional_but_recommended){
  const ex = exists(f);
  console.log(ex ? "✅" : "⚠️", f);
}
process.exit(ok ? 0 : 1);


// === Extra checks (v1.1) ===
const idx = fs.readFileSync(path.resolve("web/index.html"),"utf8");
if(idx.includes("cdn.jsdelivr.net") || idx.includes("unpkg.com")){
  console.log("❌ index.html ainda aponta para CDN. Troque para web/vendor/phaser.min.js");
  ok = false;
}else{
  console.log("✅ Sem dependência CDN no index.html");
}

const ph = path.resolve("web/vendor/phaser.min.js");
try{
  const st = fs.statSync(ph);
  if(st.size < 50000){
    console.log(`❌ Phaser local parece placeholder (${st.size} bytes). Rode: npm run build:fetch-phaser`);
    ok = false;
  }else{
    console.log(`✅ Phaser local OK (${st.size} bytes)`);
  }
}catch(e){
  console.log("❌ Phaser local ausente. Rode: npm run build:fetch-phaser");
  ok = false;
}
