# VERSION_NOTES — v2 Mobile Ready (No-Login)

## Correções
- Remove dependência direta de Phaser via CDN (prefer local `web/vendor/phaser.min.js` com fallback).
- Adiciona Touch HUD (D‑Pad + A/B/C/D + OK/VOLTA).
- Adiciona Scale FIT + autoCenter no Phaser.
- Desativa Service Worker dentro do Capacitor (APK).
- Ajusta SW para incluir vendor/phaser e evitar cache de arquivo inexistente.
- Menu e itens clicáveis (touch).
- Hub: OK/VOLTA também funciona via touch.
- Fight/Academy/Cards: polling básico para mobile (A–D/OK/VOLTA).

## Observação
Para **offline 100%**, rode `node tools/build_agent/fetch_phaser.js` antes de gerar o APK.


## v1.2
- Tatame Live UI integrada (cena tatame_live)
- Save robusto com backup + migração
- Back button Android -> ESC/Menu (mobile-back.js)
