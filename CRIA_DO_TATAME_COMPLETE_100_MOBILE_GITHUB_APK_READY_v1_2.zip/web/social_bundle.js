// social_bundle.js
// Tatame Live — versão global (sem ES modules) para integrar fácil no game.js
(function(){
  const STORAGE_PREFIX = "cria:social:";
  const BANK_PATH = "src/social/";

  function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }

  const Social = {
    banks: null,
    state: null,
    async loadBanks(){
      if(this.banks) return this.banks;
      const [posts, comments, sponsors, algorithm] = await Promise.all([
        fetch(BANK_PATH+"posts_templates.json").then(r=>r.json()),
        fetch(BANK_PATH+"comments_bank.json").then(r=>r.json()),
        fetch(BANK_PATH+"sponsors.json").then(r=>r.json()),
        fetch(BANK_PATH+"algorithm_rules.json").then(r=>r.json()),
      ]);
      this.banks = { posts, comments, sponsors, algorithm };
      return this.banks;
    },
    loadState(){
      try{
        const raw = localStorage.getItem(STORAGE_PREFIX+"state");
        if(raw) return JSON.parse(raw);
      }catch(e){}
      return { followers: 250, engagement: 10, public_image: 60, lastFeedDay:-1, feed:[], inbox:[], sponsor:null };
    },
    saveState(){
      try{ localStorage.setItem(STORAGE_PREFIX+"state", JSON.stringify(this.state)); }catch(e){}
    },
    init(){
      this.state = this.loadState();
      return this.state;
    },
    calcEngagementDelta(vars, flags){
      const w = this.banks.algorithm.weights;
      let e = (vars.honra||0)*w.honra + (vars.heat||0)*w.heat + (vars.wanted||0)*w.wanted;
      if(flags && flags.severe_injury_event) e += w.severe_injury_event;
      if(flags && flags.callout) e += w.callout;
      if(flags && flags.official_title) e += w.official_title;
      if(flags && flags.underground_title) e += w.underground_title;
      return Math.max(0, Math.round(e));
    },
    generateDailyFeed(dayIndex, vars){
      if(this.state.lastFeedDay === dayIndex && this.state.feed && this.state.feed.length) return this.state.feed;
      const posts = this.banks.posts;
      const count = 5 + Math.floor(Math.random()*5);
      const picks = [];
      for(let i=0;i<count;i++){
        let pool = posts;
        if((vars.wanted||0) >= 4) pool = posts.filter(p => ["controversy","headline","underground_win","callout"].includes(p.type));
        else if((vars.honra||0) > (vars.heat||0)) pool = posts.filter(p => ["clean_win","points_win","training","sponsor","headline"].includes(p.type));
        else if((vars.heat||0) > 30) pool = posts.filter(p => ["underground_win","callout","headline","training"].includes(p.type));
        const p = pool[Math.floor(Math.random()*pool.length)];
        picks.push(Object.assign({}, p, { runtime_id: `d${dayIndex}_${i}_${p.id}` }));
      }
      this.state.feed = picks;
      this.state.lastFeedDay = dayIndex;
      this.saveState();
      return picks;
    },
    processFightResult(vars, result){
      const flags = {
        severe_injury_event: !!result.severeInjury,
        underground_title: !!result.title && result.type === "underground",
        official_title: !!result.title && result.type === "official",
        callout: !!result.callout
      };
      const delta = this.calcEngagementDelta(vars, flags);
      this.state.engagement = clamp(this.state.engagement + Math.round(delta*0.05), 0, 999);
      const viral = delta >= this.banks.algorithm.viral_threshold;
      const followersGain = Math.round((this.state.engagement + delta)*this.banks.algorithm.follower_gain_mult) + (viral ? 500 : 0);
      this.state.followers = Math.max(0, this.state.followers + followersGain);
      if((vars.wanted||0) >= 4) this.state.public_image = clamp(this.state.public_image - this.banks.algorithm.image_public_penalty_wanted4, 0, 100);
      else if(result.type==="official" && result.win && !result.severeInjury) this.state.public_image = clamp(this.state.public_image + 3, 0, 100);
      this.state.inbox.unshift({ id:"msg_"+Date.now(), from:"@TatameLive", text: viral ? "Seu nome explodiu no feed. Todo mundo tá falando de você." : "O feed reagiu ao seu último evento.", ts:Date.now() });
      this.saveState();
      return { delta, viral, followersGain };
    },
    respondToPost(kind, vars){
      // kind: 'polite'|'trash'|'ignore'
      if(kind==='polite'){ vars.honra = clamp((vars.honra||0)+2,0,100); this.state.public_image = clamp(this.state.public_image+2,0,100); }
      if(kind==='trash'){ vars.heat = clamp((vars.heat||0)+3,0,100); this.state.engagement = clamp(this.state.engagement+5,0,999); if((vars.wanted||0)>=3) vars.wanted = clamp((vars.wanted||0)+1,0,5); }
      // ignore: nothing
      this.saveState();
      return vars;
    }
  };

  window.TatameLive = Social;
})();
