# CRIA DO TATAME — Prompts prontos para Google Stitch (UI + front-end code)

> **Importante**: Stitch é uma ferramenta de **UI design + geração de front-end code**, ideal pra telas/fluxos/menus.
> Para o **motor do jogo** (combate/Phaser), use a tela “Game” como um container de canvas/webview e conecte ao código do protótipo.

## Como usar no Stitch (fluxo recomendado)
1) Cole o **MASTER PROMPT** (abaixo) e gere a primeira versão do app.
2) Depois, refine “screen by screen”: cole **PROMPTS POR TELA** (abaixo), um por vez.
3) Exporte o código front-end gerado e integre com o motor do jogo (Phaser) como uma rota/tela.

---

## MASTER PROMPT (cole inteiro)

Design a mobile-first app UI called **CRIA DO TATAME** (Brazilian Jiu-Jitsu RPG). Style: premium modern 16-bit / pixel-inspired UI (not heavy pixel art), dark theme, elegant, high contrast, rounded cards, subtle Bahia/Brazil geometric motifs (no readable text in flags, use abstract stripes). Language: Portuguese (pt-BR).

App goal: a story-driven BJJ progression game (official GI tournaments + underground No-Gi sand fights + optional MMA cage path) where player builds a technique loadout (“cards”), trains in an academy, levels up techniques, and follows a conspiracy storyline that leads to an international tournament in Abu Dhabi called **Aleluyopolis Grand Championship**, and a mentor camp with **Master Satoshi**.

Create the following screens with a bottom navigation bar:
1) Home (Dashboard)
2) Train (Academy)
3) Fight (Select event)
4) Techniques (Cards/Loadout)
5) Journal (Story/Conspiracy)

### Home (Dashboard)
- Player header card with avatar, belt, team, money, Respect, Heat, Honor, Leverage.
- Big CTA: “Treinar agora”, “Ir para campeonato”.
- Story banner with current chapter and next objective.
- Quick stats: most-used technique, best win condition.

### Train (Academy)
- Technique selector (dropdown + search)
- “Drill mode” widget: a timing bar mini-game area (placeholder).
- Training options: Drill / Positional sparring / Conditioning / Rest.
- Show XP gained per technique and mastery level.

### Fight (Select event)
- Tabs: Official (GI) / Underground (No-Gi sand) / MMA (Cage) / Aleluyopolis (locked until conditions).
- Each event card shows rules summary, reward, and risk.
- Pre-fight screen with loadout summary + “Start fight”.

### Techniques (Cards/Loadout)
- Grid/list of technique cards with rarity border by belt tier.
- Each card shows: name, category, mode (GI/No-Gi), position, mastery level, XP bar.
- Loadout builder: 8 active techniques + 3 reactions + 1 signature.
- Filter chips: Standing, Guard, Half, Pass, Control, Back, Submissions.

### Journal (Story/Conspiracy)
- Story timeline: Chapter cards.
- Evidence inventory (icon list) and “Suspicion meter”.
- NPC contacts list (coach, journalist, promoter, Master Satoshi).
- Decision log: choices that affected Respect/Heat/Honor.

Design system:
- Use a consistent color palette inspired by Bahia coastal blues + warm sand + subtle gold accents.
- UI components: cards, chips, progress bars, icon buttons.
- Provide responsive layout for mobile.

Deliver code as clean front-end components (React or HTML/CSS) with clear structure. Include placeholder components for the Game canvas screen that can embed a Phaser canvas.

---

## PROMPTS POR TELA (use para refinar)

### 1) Home
On Home, make the player header card more compact, with a belt color indicator and team badge. Add a “Weekly plan” mini-card showing 7-day streak and next training block. Make the story banner more cinematic with a subtle Abu Dhabi desert gradient and a “locked/unlocked” label for Aleluyopolis.

### 2) Train
On Train, add a segmented control for Drill / Positional / Conditioning / Rest. Add a detailed technique mastery panel with: Level, XP bar, “Perfect timing rate”, and “Efficiency bonus” summary. Add a button “Treinar com Satoshi” that is disabled until Aleluyopolis is unlocked.

### 3) Fight
On Fight selection, redesign cards so they show: Rules, Time, Win conditions, Rewards, Risk (Heat). Add a pre-fight modal summarizing loadout and recommended counters based on opponent archetype.

### 4) Techniques
On Techniques, improve the card grid: show an icon for category and position. Add sort options: Most used, Highest mastery, Lowest mastery. Add a “Build presets” section: Pressure GI, Sweep Guard, Back Hunter, Wrestling Base.

### 5) Journal
On Journal, add an “Evidence Board” layout (pinboard style). Add a “Conspiracy progress” bar that unlocks a final chapter choice. Add a log that lists last 10 outcomes with deltas for Respect/Heat/Honor.
