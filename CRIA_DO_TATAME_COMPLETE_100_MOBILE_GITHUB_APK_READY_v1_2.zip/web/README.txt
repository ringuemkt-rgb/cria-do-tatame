CRIA DO TATAME — Stitch Pack v2 (UI prompts + protótipo jogável)

O que tem aqui:
- Protótipo jogável em HTML/JS (Phaser) com foco em:
  • evolução de técnicas (LVL + XP + taxa de timing)
  • loadout (8 técnicas)
  • GI Oficial com pontuação por estabilização (3s)
  • Submundo NO-GI na areia (dominância)
  • Jornal da conspiração (evidências/suspeita)
  • Aleluyopolis (Abu Dhabi) + Camp do Mestre Satoshi (passivas)
  • Rota MMA (cage) — protótipo

Como rodar (web):
- Abra index.html no navegador.
- Se precisar: python -m http.server 8000

Como usar com Stitch:
- Cole o MASTER PROMPT no Stitch, gere as telas.
- Refine screen-by-screen com os prompts por tela.
- Exporte o front-end code e integre com o motor Phaser (tela de jogo com canvas).

Como empacotar APK:
- Use Capacitor.
- Para offline, baixe phaser.min.js e referencie localmente.
