
/**
 * Simple storage adapter (localStorage) with JSON.
 * In Capacitor, can be replaced with Filesystem/Preferences for robustness.
 */
export class JsonStorage {
  constructor(prefix="cria") { this.prefix = prefix; }
  async get(key) {
    const raw = localStorage.getItem(`${this.prefix}:${key}`);
    if (!raw) return null;
    try { return JSON.parse(raw); } catch { return null; }
  }
  async set(key, value) {
    localStorage.setItem(`${this.prefix}:${key}`, JSON.stringify(value));
  }
}
