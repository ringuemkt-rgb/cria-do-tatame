
/**
 * Feed Generator — converts templates into UI-friendly items
 * Keeps content short (mobile) and supports localization (pt-BR baseline).
 */
export function formatFeedItems(feed) {
  return feed.map(p => ({
    id: p.runtime_id || p.id,
    author: p.author,
    text: p.text,
    likes: p.likes,
    comments: p.comments,
    tags: p.tags || []
  }));
}
