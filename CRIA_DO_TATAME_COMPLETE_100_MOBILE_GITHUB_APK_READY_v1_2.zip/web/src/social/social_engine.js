
/**
 * Tatame Live — Social Engine (offline, deterministic-friendly)
 * - Generates daily feed from templates + player state
 * - Impacts: honra / heat / wanted / followers / engagement / public_image
 * - Stores in Save + cache
 */
export class SocialEngine {
  constructor(storage, rng) {
    this.storage = storage; // should expose get(key), set(key,val)
    this.rng = rng || Math.random;
    this.state = null;
    this.banks = null;
  }

  async init(banksLoader) {
    this.banks = await banksLoader();
    this.state = (await this.storage.get("social_state")) || this.defaultState();
    return this.state;
  }

  defaultState() {
    return {
      followers: 250,
      engagement: 10,
      public_image: 60, // 0..100
      lastFeedDay: -1,
      inbox: [],
      feed: [],
      sponsor: null
    };
  }

  // Calculate engagement delta based on game variables + event flags
  calcEngagementDelta(vars, flags) {
    const w = this.banks.algorithm.weights;
    let e =
      (vars.honra || 0) * w.honra +
      (vars.heat || 0) * w.heat +
      (vars.wanted || 0) * w.wanted +
      (flags?.severe_injury_event ? w.severe_injury_event : 0) +
      (flags?.callout ? w.callout : 0) +
      (flags?.official_title ? w.official_title : 0) +
      (flags?.underground_title ? w.underground_title : 0);
    return Math.max(0, Math.round(e));
  }

  // Create a daily feed (5..9 posts) based on vars
  generateDailyFeed(dayIndex, vars) {
    if (this.state.lastFeedDay === dayIndex && this.state.feed?.length) return this.state.feed;

    const posts = this.banks.posts;
    const count = 5 + Math.floor(this.rng() * 5);

    // Bias selection by wanted/heat/honra
    const picks = [];
    for (let i = 0; i < count; i++) {
      let pool = posts;
      if ((vars.wanted || 0) >= 4) pool = posts.filter(p => ["controversy","headline","underground_win","callout"].includes(p.type));
      else if ((vars.honra || 0) > (vars.heat || 0)) pool = posts.filter(p => ["clean_win","points_win","training","sponsor","headline"].includes(p.type));
      else if ((vars.heat || 0) > 30) pool = posts.filter(p => ["underground_win","callout","headline","training"].includes(p.type));

      const p = pool[Math.floor(this.rng() * pool.length)];
      picks.push({...p, runtime_id: `d${dayIndex}_${i}_${p.id}`});
    }

    this.state.feed = picks;
    this.state.lastFeedDay = dayIndex;
    return picks;
  }

  // Apply fight result to social metrics + optionally generate a headline
  processFightResult(vars, result) {
    // result: {type:'official'|'underground', win:boolean, points:{you,opp}, severeInjury:boolean, callout:boolean}
    const flags = {
      severe_injury_event: !!result.severeInjury,
      underground_title: !!result.title && result.type === "underground",
      official_title: !!result.title && result.type === "official",
      callout: !!result.callout
    };

    const delta = this.calcEngagementDelta(vars, flags);
    this.state.engagement = clamp(this.state.engagement + Math.round(delta * 0.05), 0, 999);
    const viral = delta >= this.banks.algorithm.viral_threshold;

    const followersGain = Math.round((this.state.engagement + delta) * this.banks.algorithm.follower_gain_mult) + (viral ? 500 : 0);
    this.state.followers = Math.max(0, this.state.followers + followersGain);

    if ((vars.wanted || 0) >= 4) {
      this.state.public_image = clamp(this.state.public_image - this.banks.algorithm.image_public_penalty_wanted4, 0, 100);
    } else if (result.type === "official" && result.win && !result.severeInjury) {
      this.state.public_image = clamp(this.state.public_image + 3, 0, 100);
    }

    // Add a small inbox event
    const msg = {
      id: `msg_${Date.now()}`,
      from: "@TatameLive",
      text: viral ? "Seu nome explodiu no feed. Todo mundo tá falando de você." : "O feed reagiu ao seu último evento.",
      ts: Date.now()
    };
    this.state.inbox.unshift(msg);

    return { delta, viral, followersGain };
  }

  // Sponsor selection based on followers + wanted
  evaluateSponsors(vars) {
    const list = this.banks.sponsors;
    const eligible = list.filter(s => this.state.followers >= s.min_followers && (vars.wanted || 0) <= s.max_wanted);
    return eligible.sort((a,b)=>b.monthly_pay-a.monthly_pay);
  }

  async save() {
    await this.storage.set("social_state", this.state);
  }
}

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
