
export async function loadTatameLiveBanks() {
  const [posts, comments, sponsors, algorithm] = await Promise.all([
    fetch("src/social/posts_templates.json").then(r=>r.json()),
    fetch("src/social/comments_bank.json").then(r=>r.json()),
    fetch("src/social/sponsors.json").then(r=>r.json()),
    fetch("src/social/algorithm_rules.json").then(r=>r.json()),
  ]);
  return { posts, comments, sponsors, algorithm };
}
