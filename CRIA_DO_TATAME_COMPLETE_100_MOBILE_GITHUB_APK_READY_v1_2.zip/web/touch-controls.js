// touch-controls.js
// Cria um InputState global (sem depender do Phaser) para ser lido pelo game.js.
// - Direções: up/down/left/right
// - Ações: A/B/C/D + ENTER + ESC
(function(){
  const state = window.InputState = window.InputState || {
    dir: {up:false,down:false,left:false,right:false},
    act: {A:false,B:false,C:false,D:false,ENTER:false,ESC:false},
    lastPress: {A:0,B:0,C:0,D:0,ENTER:0,ESC:0}
  };

  function setDir(k, v){ if(state.dir[k] !== v) state.dir[k]=v; }
  function pulseAct(k){
    state.act[k] = true;
    state.lastPress[k] = Date.now();
  }

  // auto-release curto para botões de ação (como "tap")
  function tick(){
    const now = Date.now();
    for(const k of Object.keys(state.act)){
      if(state.act[k] && now - state.lastPress[k] > 120) state.act[k] = false;
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  function bindButton(btn){
    const dir = btn.dataset.dir;
    const act = btn.dataset.act;

    const down = (e)=>{
      e.preventDefault();
      if(dir) setDir(dir, true);
      if(act) pulseAct(act);
    };
    const up = (e)=>{
      e.preventDefault();
      if(dir) setDir(dir, false);
      // act já é pulse
    };

    btn.addEventListener('pointerdown', down, {passive:false});
    btn.addEventListener('pointerup', up, {passive:false});
    btn.addEventListener('pointercancel', up, {passive:false});
    btn.addEventListener('pointerleave', up, {passive:false});
  }

  window.addEventListener('DOMContentLoaded', ()=>{
    document.querySelectorAll('#touchHud button').forEach(bindButton);
  });
})();
