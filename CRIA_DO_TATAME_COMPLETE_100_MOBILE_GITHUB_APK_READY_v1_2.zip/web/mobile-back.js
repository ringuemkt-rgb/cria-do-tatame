// mobile-back.js
// Captura botão VOLTAR no Android (Capacitor) e converte em ESC/Menu dentro do jogo.
// Fallback: escKey dispatch para webview sem Capacitor.
(function(){
  function dispatchEsc(){
    try{
      window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code:'Escape', keyCode:27, which:27, bubbles:true }));
    }catch(e){}
    // Também marca no InputState (touch-controls) se existir:
    if(window.InputState && window.InputState.act){ window.InputState.act.ESC = true; setTimeout(()=>window.InputState.act.ESC=false, 80); }
  }

  // Capacitor App plugin (se disponível)
  const cap = window.Capacitor;
  if(cap && cap.Plugins && cap.Plugins.App && cap.Plugins.App.addListener){
    cap.Plugins.App.addListener('backButton', () => {
      dispatchEsc();
    });
  } else if(cap && cap.isNativePlatform && cap.isNativePlatform()){
    // tentativa genérica
    document.addEventListener('backbutton', (e)=>{ e.preventDefault(); dispatchEsc(); }, false);
  }
})();
