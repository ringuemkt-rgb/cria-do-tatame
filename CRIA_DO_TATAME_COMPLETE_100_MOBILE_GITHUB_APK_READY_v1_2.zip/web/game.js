
/*
CRIA DO TATAME — Prototype v2
- Fix: no per-frame text creation (performance)
- Official scoring uses stabilization timer (3s)
- Adds: Journal/Conspiracy, Aleluyopolis unlock, Master Satoshi passives, MMA cage prototype
*/

const SAVE_KEY = "cria_do_tatame_save_v2";
const SAVE_BAK_KEY = SAVE_KEY + "_bak";
const SAVE_VERSION = 2;

function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }
function lerp(a,b,t){ return a + (b-a)*t; }
function rnd(){ return Math.random(); }

const Teams = {
  barreiraVermelha: { id:"barreiraVermelha", name:"Barreira Vermelha JJ", colors:["#e11d48","#f8fafc"], bonus:{giGrip:0.10, pressure:0.10, pass:0.08} },
  aliancaDoMar: { id:"aliancaDoMar", name:"Aliança do Mar", colors:["#2563eb","#f8fafc","#f59e0b"], bonus:{sweep:0.12, transition:0.08, iq:0.08} },
  uniaoReconcavo: { id:"uniaoReconcavo", name:"União do Recôncavo Grappling", colors:["#16a34a","#f59e0b","#111827"], bonus:{takedown:0.12, balance:0.10, explode:0.08} },
  cascaDeAco: { id:"cascaDeAco", name:"Casca de Aço", colors:["#111827","#9ca3af","#7c3aed"], bonus:{back:0.12, sub:0.10, dominance:0.08} },
};

const Belts = ["Branca","Azul","Roxa","Marrom","Preta"];

const TechniqueDB = [
  // Standing / Clinch
  { id:"double_leg", name:"Double Leg", mode:"AMBOS", cat:"Queda", pos:"Em Pé", minBelt:0, tags:["takedown"], stam:24, base:0.52 },
  { id:"single_leg", name:"Single Leg", mode:"AMBOS", cat:"Queda", pos:"Em Pé", minBelt:0, tags:["takedown"], stam:18, base:0.54 },
  { id:"body_lock_trip", name:"Body Lock Trip", mode:"NO_GI", cat:"Queda", pos:"Clinch", minBelt:1, tags:["takedown"], stam:16, base:0.58 },
  { id:"snapdown_fh", name:"Snapdown → Front Headlock", mode:"AMBOS", cat:"Transição", pos:"Em Pé", minBelt:1, tags:["iq","control"], stam:10, base:0.60 },
  { id:"guard_pull", name:"Puxada pra Guarda", mode:"GI", cat:"Transição", pos:"Em Pé", minBelt:0, tags:["guard"], stam:8, base:0.62 },

  // Sweeps / Guard
  { id:"hip_bump", name:"Raspagem Hip Bump", mode:"GI", cat:"Raspagem", pos:"Guarda (baixo)", minBelt:1, tags:["sweep"], stam:16, base:0.54 },
  { id:"scissor", name:"Raspagem Tesoura", mode:"GI", cat:"Raspagem", pos:"Guarda (baixo)", minBelt:1, tags:["sweep"], stam:18, base:0.52 },
  { id:"butterfly", name:"Raspagem Borboleta", mode:"NO_GI", cat:"Raspagem", pos:"Guarda (baixo)", minBelt:2, tags:["sweep"], stam:18, base:0.53 },
  { id:"half_uh_sweep", name:"Meia Guarda Underhook", mode:"AMBOS", cat:"Raspagem", pos:"Meia (baixo)", minBelt:1, tags:["sweep"], stam:14, base:0.58 },

  // Pass / Control
  { id:"knee_slice", name:"Passagem Knee Slice", mode:"AMBOS", cat:"Passagem", pos:"Guarda (cima)", minBelt:1, tags:["pass","pressure"], stam:16, base:0.56 },
  { id:"toreando", name:"Passagem Toreando", mode:"GI", cat:"Passagem", pos:"Guarda (cima)", minBelt:1, tags:["pass"], stam:14, base:0.54 },
  { id:"body_lock_pass", name:"Body Lock Pass", mode:"NO_GI", cat:"Passagem", pos:"Guarda (cima)", minBelt:2, tags:["pass","pressure"], stam:16, base:0.58 },
  { id:"knee_on_belly", name:"Joelho na Barriga", mode:"AMBOS", cat:"Controle", pos:"Side (cima)", minBelt:1, tags:["control","pressure"], stam:12, base:0.60 },
  { id:"mount_stable", name:"Montada Firme", mode:"AMBOS", cat:"Controle", pos:"Montada", minBelt:1, tags:["control","pressure"], stam:12, base:0.62 },
  { id:"back_take", name:"Pegar Costas", mode:"AMBOS", cat:"Transição", pos:"Turtle/Side", minBelt:2, tags:["back","control"], stam:16, base:0.53 },
  { id:"seatbelt", name:"Seatbelt (Cinto)", mode:"AMBOS", cat:"Controle", pos:"Costas", minBelt:1, tags:["back","control"], stam:8, base:0.65 },

  // Submissions (game-safe, no step-by-step)
  { id:"rnc", name:"Mata-Leão (RNC)", mode:"NO_GI", cat:"Finalização", pos:"Costas", minBelt:1, tags:["sub","back"], stam:14, base:0.60 },
  { id:"guillotine", name:"Guilhotina", mode:"NO_GI", cat:"Finalização", pos:"Front Headlock", minBelt:1, tags:["sub"], stam:14, base:0.54 },
  { id:"arm_triangle", name:"Triângulo de Braço", mode:"NO_GI", cat:"Finalização", pos:"Side/Montada", minBelt:3, tags:["sub","pressure"], stam:16, base:0.58 },
  { id:"triangle", name:"Triângulo", mode:"AMBOS", cat:"Finalização", pos:"Guarda (baixo)", minBelt:2, tags:["sub"], stam:18, base:0.52 },
  { id:"armbar", name:"Armlock (Juji)", mode:"AMBOS", cat:"Finalização", pos:"Guarda/Montada", minBelt:1, tags:["sub"], stam:16, base:0.52 },
  { id:"cross_collar", name:"Estrangulamento de Gola (X)", mode:"GI", cat:"Finalização", pos:"Guarda/Montada", minBelt:2, tags:["sub","giGrip"], stam:14, base:0.54 },
  { id:"bow_arrow", name:"Arco e Flecha", mode:"GI", cat:"Finalização", pos:"Costas", minBelt:3, tags:["sub","giGrip","back"], stam:18, base:0.56 },

  // MMA (simple strikes; sport context)
  { id:"jab_cross", name:"Jab-Cross", mode:"MMA", cat:"Striking", pos:"Em Pé", minBelt:0, tags:["mma","strike"], stam:10, base:0.62 },
  { id:"low_kick", name:"Chute Baixo", mode:"MMA", cat:"Striking", pos:"Em Pé", minBelt:1, tags:["mma","strike"], stam:12, base:0.58 },
  { id:"cage_clinch", name:"Clinch na Grade", mode:"MMA", cat:"Controle", pos:"Clinch", minBelt:1, tags:["mma","control"], stam:12, base:0.60 },
];

function defaultSave(){
  const tech = {};
  TechniqueDB.forEach(t=>{
    tech[t.id] = { lvl:1, xp:0, perfect:0, tries:0 };
  });
  return {
    version: 2,
    player: {
      name: "Cria",
      belt: 0,
      team: Teams.aliancaDoMar.id,
      money: 120,
      respect: 10,
      heat: 0,
      honor: 10,
      leverage: 0,
      stats: { gas: 100, explosao: 10, pressao: 10, mobilidade: 10, gi: 10, nogi: 10, foco: 10, iq: 10, mma: 5 },
      loadout: {
        active: ["double_leg","single_leg","knee_slice","half_uh_sweep","mount_stable","back_take","armbar","triangle"],
        reacts: ["sprawl","guard_retain","frame_escape"],
        signature: "team_signature"
      }
    },
    story: {
      chapter: 1,
      suspicion: 0,
      evidence: [],
      aleluyopolisUnlocked: false,
      satoshi: { kuzushi:0, breath:0, chain:0, cold:0 },
      satoshiMet: false,
      aleluyopolisWins: 0,
      mmaRoute: false
    },
    tech
  };
}

function loadSave(){
  // Try primary save, then backup. Never return invalid.
  const tryParse = (raw)=>{
    try{
      const obj = JSON.parse(raw);
      return migrateSave(obj);
    }catch(e){ return null; }
  };
  let obj = null;
  const raw = localStorage.getItem(SAVE_KEY);
  if(raw) obj = tryParse(raw);
  if(!validateSave(obj)){
    const bak = localStorage.getItem(SAVE_BAK_KEY);
    if(bak) obj = tryParse(bak);
  }
  if(!validateSave(obj)) obj = defaultSave();
  return obj;
}
function saveGame(s){
  try{
    s.version = SAVE_VERSION;
    // Backup current save before overwriting
    const cur = localStorage.getItem(SAVE_KEY);
    if(cur) localStorage.setItem(SAVE_BAK_KEY, cur);
    const payload = JSON.stringify(s);
    localStorage.setItem(SAVE_KEY, payload);
  }catch(e){
    // last resort: try backup slot
    try{ localStorage.setItem(SAVE_BAK_KEY, JSON.stringify(s)); }catch(_){}
  }
}

const GameState = { save: loadSave() };
// Tatame Live (rede social)
if(window.TatameLive){ window.TatameLive.init(); }

function teamObj(){ return Teams[GameState.save.player.team] || Teams.aliancaDoMar; }
function techDef(id){ return TechniqueDB.find(t=>t.id===id); }
function techState(id){ return GameState.save.tech[id]; }
function beltName(){ return Belts[GameState.save.player.belt] || "Branca"; }

function canUseTech(id, mode){
  const t = techDef(id);
  if(!t) return false;
  if(GameState.save.player.belt < t.minBelt) return false;
  if(t.mode==="AMBOS") return (mode!=="MMA_CAGE");
  if(t.mode==="MMA") return (mode==="MMA_CAGE");
  if(mode==="NO_GI_SAND") return (t.mode==="NO_GI" || t.mode==="AMBOS");
  return t.mode === mode;
}

function techSuccessChance(id, mode){
  const t = techDef(id);
  const ts = techState(id);
  const pl = GameState.save.player;
  const team = teamObj();
  const st = GameState.save.story;

  let chance = t.base;
  chance += (ts.lvl-1) * 0.022;
  const rate = ts.tries>0 ? (ts.perfect/ts.tries) : 0;
  chance += clamp(rate,0,0.8) * 0.06;
  chance += pl.belt * 0.01;

  if(mode==="GI") chance += pl.stats.gi * 0.003;
  if(mode==="NO_GI_SAND" || mode==="NO_GI") chance += pl.stats.nogi * 0.003;
  if(mode==="MMA_CAGE") chance += pl.stats.mma * 0.003;

  chance += st.satoshi.kuzushi * 0.01;
  chance += st.satoshi.chain * 0.006;
  chance += st.satoshi.cold * 0.004;

  if(t.tags.includes("takedown")) chance += (team.bonus.takedown || 0) * 0.5;
  if(t.tags.includes("sweep")) chance += (team.bonus.sweep || 0) * 0.5;
  if(t.tags.includes("pressure") || t.tags.includes("pass")) chance += (team.bonus.pressure || 0) * 0.35 + (team.bonus.pass||0)*0.35;
  if(t.tags.includes("giGrip")) chance += (team.bonus.giGrip || 0) * 0.5;
  if(t.tags.includes("back")) chance += (team.bonus.back || 0) * 0.5;
  if(t.tags.includes("sub")) chance += (team.bonus.sub || 0) * 0.4;

  return clamp(chance, 0.10, 0.90);
}

function techStaminaCost(id, mode){
  const t = techDef(id);
  const ts = techState(id);
  const team = teamObj();
  const st = GameState.save.story;

  let cost = t.stam;
  cost *= (1 - (ts.lvl-1)*0.045);
  cost *= (1 - st.satoshi.breath*0.04);

  if(t.tags.includes("takedown")) cost *= (1 - (team.bonus.takedown||0)*0.4);
  if(t.tags.includes("sweep")) cost *= (1 - (team.bonus.sweep||0)*0.4);
  if(t.tags.includes("pressure") || t.tags.includes("pass")) cost *= (1 - ((team.bonus.pressure||0)+(team.bonus.pass||0))*0.25);
  if(t.tags.includes("giGrip")) cost *= (1 - (team.bonus.giGrip||0)*0.35);
  if(t.tags.includes("back")) cost *= (1 - (team.bonus.back||0)*0.35);

  if(mode==="NO_GI_SAND") cost *= 1.15;
  return Math.max(5, Math.round(cost));
}

function addTechXP(id, amount){
  const ts = techState(id);
  ts.xp += amount;
  const need = 45 + (ts.lvl-1)*42;
  if(ts.xp >= need && ts.lvl < 7){
    ts.xp -= need;
    ts.lvl += 1;
  }
}

function recordDrill(id, perfect){
  const ts = techState(id);
  ts.tries += 1;
  if(perfect) ts.perfect += 1;
}

function maybeBeltUp(){
  const pl = GameState.save.player;
  const levels = Object.values(GameState.save.tech).map(x=>x.lvl);
  const avg = levels.reduce((a,b)=>a+b,0)/levels.length;
  const target = [1.2, 1.8, 2.6, 3.6, 4.8];
  if(pl.belt < 4 && avg >= target[pl.belt+1]){
    pl.belt += 1;
    pl.respect += 12;
    pl.money += 140;
  }
}

function maybeUnlockAleluyopolis(){
  const s = GameState.save;
  if(s.story.aleluyopolisUnlocked) return;
  const cond1 = s.player.belt >= 2;
  const cond2 = (s.player.respect >= 35) || (s.player.heat >= 35) || (s.story.evidence.length>=3);
  if(cond1 && cond2){
    s.story.aleluyopolisUnlocked = true;
    s.story.chapter = Math.max(s.story.chapter, 4);
  }
}

const GameStateSingleton = GameState;

// MobileInput (touch HUD) — lê window.InputState (touch-controls.js)
const MobileInput = {
  state(){ return (typeof window!=="undefined" && window.InputState) ? window.InputState : null; },
  dir(k){
    const s = this.state(); if(!s) return false;
    return !!(s.dir && s.dir[k]);
  },
  // Edge-trigger: consome 'pulse' do botão (A/B/C/D/ENTER/ESC)
  consume(scene, k){
    const s = this.state(); if(!s) return false;
    scene.__actConsumed = scene.__actConsumed || {};
    const last = s.lastPress?.[k] || 0;
    const prev = scene.__actConsumed[k] || 0;
    if(last && last !== prev){
      scene.__actConsumed[k] = last;
      return true;
    }
    return false;
  }
};

/////////////////////////////
// Phaser scenes
/////////////////////////////
const WIDTH = 960, HEIGHT = 540;


class TatameLiveScene extends Phaser.Scene {
  constructor(){ super("tatame_live"); }
  async create(){
    this.add.rectangle(0,0,960,540,0x0b1220).setOrigin(0,0);
    this.add.text(24,18,"TATAME LIVE", {fontSize:"22px", color:"#e8eef6"});
    this.add.text(24,44,"Feed estilo GTA • ENTER=Responder • ESC=Voltar", {fontSize:"13px", color:"#b7c2d2"});

    // Load banks once
    if(window.TatameLive){
      await window.TatameLive.loadBanks();
    }

    // Day index simplistic: based on total fights + trainings
    const dayIndex = (GameState.save.story.day||0);
    const vars = { honra: GameState.save.player.honor||0, heat: GameState.save.player.heat||0, wanted: GameState.save.player.wanted||0 };
    const feed = window.TatameLive ? window.TatameLive.generateDailyFeed(dayIndex, vars) : [];

    this.items = feed.slice(0,8);
    this.sel = 0;

    this.panel = this.add.rectangle(24,80,912,420,0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);
    this.renderFeed();

    this.cursors = this.input.keyboard.createCursorKeys();
    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("hub"));

    this.input.keyboard.on("keydown-ENTER", ()=>{
      // responder com 3 opções rápidas; alterna a cada ENTER para protótipo
      const kind = (this.sel % 3 === 0) ? "polite" : (this.sel % 3 === 1 ? "trash" : "ignore");
      const v2 = window.TatameLive ? window.TatameLive.respondToPost(kind, vars) : vars;
      GameState.save.player.honor = v2.honra;
      GameState.save.player.heat = v2.heat;
      GameState.save.player.wanted = v2.wanted;
      saveGame(GameState.save);
      this.flash(kind);
      this.renderFeed();
    });
  }

  flash(kind){
    const msg = kind==="polite" ? "+Honra / +Imagem" : (kind==="trash" ? "+Heat / +Engajamento (risco Wanted)" : "Ignorou");
    const t = this.add.text(24,510, msg, {fontSize:"14px", color:"#fbbf24"});
    this.time.delayedCall(900, ()=> t.destroy());
  }

  renderFeed(){
    if(this.lines) this.lines.forEach(l=>l.destroy());
    this.lines = [];
    const x=40, y0=96;
    const lineH=46;
    this.items.forEach((p,i)=>{
      const y = y0 + i*lineH;
      const bg = this.add.rectangle(x, y, 880, 40, i===this.sel?0x1f2937:0x111827).setOrigin(0,0).setAlpha(0.95);
      const author = this.add.text(x+10, y+6, p.author, {fontSize:"12px", color:"#93c5fd"});
      const txt = this.add.text(x+10, y+20, p.text.slice(0,92), {fontSize:"12px", color:"#e8eef6"});
      const stats = this.add.text(x+760, y+12, `❤ ${p.likes}  💬 ${p.comments}`, {fontSize:"11px", color:"#b7c2d2"});
      this.lines.push(bg, author, txt, stats);
    });
  }

  update(){
    const up = this.cursors.up.isDown || MobileInput.dir('up');
    const down = this.cursors.down.isDown || MobileInput.dir('down');
    if(!this._cool) this._cool = 0;
    this._cool -= this.game.loop.delta;
    if(this._cool<=0){
      if(up){ this.sel = (this.sel+this.items.length-1)%this.items.length; this._cool=160; this.renderFeed(); }
      if(down){ this.sel = (this.sel+1)%this.items.length; this._cool=160; this.renderFeed(); }
    }
  }
}


const config = {
  type: Phaser.AUTO,
  parent: "game",
  width: WIDTH,
  height: HEIGHT,
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  backgroundColor: "#0b0f14",
  pixelArt: true,
  roundPixels: true,
  physics: { default: "arcade", arcade: { gravity: { y: 0 }, debug: false } },
  scene: []
};

class BootScene extends Phaser.Scene { constructor(){ super("boot"); } create(){ this.scene.start("menu"); } }

class MenuScene extends Phaser.Scene {
  constructor(){ super("menu"); }
  create(){
    const s = GameStateSingleton.save;
    maybeUnlockAleluyopolis();
    saveGame(s);

    const t = teamObj();
    this.add.text(30, 24, "CRIA DO TATAME", { fontSize:"32px", color:"#e8eef6" });
    this.add.text(30, 62, "v2 • combate + evolução de técnicas + história (conspiração/Aleluyopolis/MMA)", { fontSize:"14px", color:"#b7c2d2" });
    this.add.rectangle(30, 92, 900, 2, 0x1f2937).setOrigin(0,0);

    const card = this.add.rectangle(30, 110, 900, 154, 0x0f172a).setOrigin(0,0);
    card.setStrokeStyle(1, 0x334155, 1);

    this.add.text(50, 132, `Lutador: ${s.player.name} • Faixa: ${beltName()} • Equipe: ${t.name}`, { fontSize:"16px", color:"#e8eef6" });
    this.add.text(50, 160, `Dinheiro: ${s.player.money} • Respeito: ${s.player.respect} • Heat: ${s.player.heat} • Honra: ${s.player.honor} • Alavanca: ${s.player.leverage}`, { fontSize:"14px", color:"#b7c2d2" });
    this.add.text(50, 186, `História: Capítulo ${s.story.chapter} • Evidências: ${s.story.evidence.length} • Suspeita: ${s.story.suspicion}%`, { fontSize:"14px", color:"#b7c2d2" });
    this.add.text(50, 212, `Aleluyopolis: ${s.story.aleluyopolisUnlocked ? "DESBLOQUEADO" : "Bloqueado"} • Satoshi: ${s.story.satoshiMet ? "Conhecido" : "—"}`, { fontSize:"14px", color:"#b7c2d2" });

    const opts = [
      ["HUB Bahia", "hub"],
      ["Academia (Treino)", "academy"],
      ["Campeonato Oficial (GI)", "fight_official"],
      ["Submundo Areia (NO-GI)", "fight_underground"],
      ["MMA Cage (protótipo)", "fight_mma"],
      [s.story.aleluyopolisUnlocked ? "Aleluyopolis (Abu Dhabi)" : "Aleluyopolis (bloqueado)", "fight_aleluyopolis"],
      ["Camp Mestre Satoshi", "satoshi_camp"],
      ["Jornal (Conspiração)", "journal"],
      ["Cartas/Técnicas (Loadout)", "cards"],
      ["Escolher Equipe", "team_select"],
      ["Reset Save", "reset"]
    ];

    this.menuItems = [];
    let y = 285;
    opts.forEach(([label, key], i)=>{
      const locked = (key==="fight_aleluyopolis" && !s.story.aleluyopolisUnlocked) || (key==="satoshi_camp" && !s.story.aleluyopolisUnlocked);
      const bg = this.add.rectangle(50, y, 560, 34, locked ? 0x0b1220 : 0x111827).setOrigin(0,0);
      bg.setStrokeStyle(1, 0x374151, 1);
      const txt = this.add.text(64, y+7, `${i+1}. ${label}`, { fontSize:"16px", color: locked? "#6b7280":"#e8eef6" });
      this.menuItems.push({bg, txt, key, locked});
      // Touch: clicar no item
      bg.setInteractive({useHandCursor:true});
      bg.on("pointerdown", ()=>{ if(locked){ this.flashLocked(bg); return; } this.handle(key); });
      txt.setInteractive({useHandCursor:true});
      txt.on("pointerdown", ()=>{ if(locked){ this.flashLocked(bg); return; } this.handle(key); });

      y += 42;
    });

    this.add.text(640, 285,
      "Dicas:\n• Treino perfeito aumenta Timing%\n• Técnica LVL alto = menos stamina + mais chance\n• GI Oficial: pontos só contam após 3s estabilizado\n• NO-GI areia: dominância pesa mais\n• Junte evidências para destravar Aleluyopolis\n• Aleluyopolis libera passivas do Satoshi",
      { fontSize:"14px", color:"#b7c2d2", lineSpacing: 7 }
    );

    this.input.keyboard.on("keydown", (e)=>{
      const n = parseInt(e.key,10);
      if(!Number.isFinite(n)) return;
      if(n>=1 && n<=opts.length){
        const item = this.menuItems[n-1];
        if(item.locked){ this.flashLocked(item.bg); return; }
        this.handle(item.key);
      }
    });
  }

  flashLocked(rect){ this.tweens.add({ targets: rect, alpha: 0.2, duration: 80, yoyo:true, repeat:2 }); }

  handle(key){
    if(key==="reset"){
      localStorage.removeItem(SAVE_KEY);
      GameStateSingleton.save = loadSave();
      this.scene.restart(); return;
    }
    if(key==="fight_aleluyopolis" && !GameStateSingleton.save.story.aleluyopolisUnlocked) return;
    if(key==="satoshi_camp" && !GameStateSingleton.save.story.aleluyopolisUnlocked) return;
    this.scene.start(key);
  }
}

class HubScene extends Phaser.Scene {
  constructor(){ super("hub"); }
  create(){
    this.add.text(24, 20, "HUB Bahia (vibe)", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "Use ENTER nos pontos • ESC volta", {fontSize:"13px", color:"#b7c2d2"});

    this.add.rectangle(40, 90, 880, 400, 0x0f172a).setOrigin(0,0).setStrokeStyle(1, 0x334155, 1);
    this.add.rectangle(40, 90, 260, 400, 0x0b4a6b).setOrigin(0,0);
    this.add.rectangle(300, 90, 40, 400, 0xcbb28f).setOrigin(0,0).setAlpha(0.95);

    for(let i=0;i<20;i++){
      const x = 360 + (i%5)*110;
      const y = 110 + Math.floor(i/5)*90;
      const c = [0xb48ead,0x81a1c1,0xa3be8c,0xd08770][i%4];
      this.add.rectangle(x, y, 82, 56, c).setOrigin(0,0).setAlpha(0.9).setStrokeStyle(1,0x111827,0.4);
      this.add.rectangle(x+6, y+6, 18, 10, 0xe0f2fe).setOrigin(0,0).setAlpha(0.5);
    }

    this.poi = [
      {x:420,y:130, label:"Academia", go:"academy"},
      {x:640,y:160, label:"Técnicas", go:"cards"},
      {x:760,y:330, label:"Praia (Itapuã)", go:"academy"},
      {x:520,y:360, label:"Submundo", go:"fight_underground"},
      {x:700,y:120, label:"Oficial", go:"fight_official"},
      {x:820,y:160, label:"Jornal", go:"journal"},
    ];
    this.poi.forEach(p=>{
      this.add.rectangle(p.x, p.y, 10, 10, 0xf59e0b);
      this.add.text(p.x+14, p.y-6, p.label, {fontSize:"12px", color:"#e8eef6"});
    });

    const g = this.add.graphics();
    g.fillStyle(0xe8eef6, 1); g.fillRect(0,0,8,8);
    g.generateTexture("pDot", 8, 8);
    g.destroy();

    this.player = this.physics.add.image(420, 260, "pDot").setOrigin(0.5);
    this.player.setCollideWorldBounds(true);

    this.cursors = this.input.keyboard.createCursorKeys();
    this.input.keyboard.on("keydown-ENTER", ()=>{
      const px = this.player.x, py = this.player.y;
      let best = null, bd = 9999;
      this.poi.forEach(p=>{
        const d = Phaser.Math.Distance.Between(px,py,p.x,p.y);
        if(d<40 && d<bd){ best=p; bd=d; }
      });
      if(best) this.scene.start(best.go);
    });
    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
  }
  update(){
    const speed = 140;
    let vx=0, vy=0;
    if(this.cursors.left.isDown || MobileInput.dir('left')) vx=-speed;
    if(this.cursors.right.isDown || MobileInput.dir('right')) vx=speed;
    if(this.cursors.up.isDown || MobileInput.dir('up')) vy=-speed;
    if(this.cursors.down.isDown || MobileInput.dir('down')) vy=speed;
    this.player.setVelocity(vx,vy);

    // Mobile: OK / VOLTA
    if(MobileInput.consume(this,'ENTER')){
      const px = this.player.x, py = this.player.y;
      let best = null, bd = 9999;
      this.poi.forEach(p=>{
        const d = Phaser.Math.Distance.Between(px,py,p.x,p.y);
        if(d<40 && d<bd){ best=p; bd=d; }
      });
      if(best) this.scene.start(best.go);
    }
    if(MobileInput.consume(this,'ESC')) this.scene.start("menu");
  }
}

class JournalScene extends Phaser.Scene {
  constructor(){ super("journal"); }
  create(){
    const s = GameStateSingleton.save;
    this.add.text(24, 20, "Jornal — Conspiração", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "ESC voltar", {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 70, 912, 2, 0x1f2937).setOrigin(0,0);

    this.add.rectangle(30, 90, 900, 420, 0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);

    const lines = [];
    lines.push(`Capítulo atual: ${s.story.chapter}`);
    lines.push(`Suspeita do sistema: ${s.story.suspicion}%`);
    lines.push(`Evidências coletadas: ${s.story.evidence.length}`);
    lines.push("");
    lines.push("Evidências:");
    if(s.story.evidence.length===0){
      lines.push("— nenhuma ainda. (Tente oficial e observe decisões do árbitro...)");
    }else{
      s.story.evidence.slice(-10).forEach(ev=> lines.push(`• ${ev}`));
    }
    lines.push("");
    lines.push("Objetivo macro:");
    lines.push(s.story.aleluyopolisUnlocked
      ? "Aleluyopolis liberado. Próximo: vencer e entrar no camp do Mestre Satoshi."
      : "Suba faixa e (Respeito OU Heat OU Evidências>=3) para destravar Aleluyopolis (Abu Dhabi)."
    );
    this.add.text(54, 120, lines.join("\n"), {fontSize:"14px", color:"#b7c2d2", lineSpacing:6});
    this.add.text(54, 430, "Dica: ficar 'limpo' sobe Respeito/Honra; submundo dá grana mas sobe Heat. Decide teu destino. 😄", {fontSize:"13px", color:"#e8eef6"});

    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
  }
  update(){ if(MobileInput.consume(this,"ESC")) this.scene.start("menu"); }
}

class CardsScene extends Phaser.Scene {
  constructor(){ super("cards"); }
  create(){
    this.add.text(24, 20, "Cartas/Técnicas (nível + timing)", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "ENTER: equipar/desequipar • ↑/↓ scroll • 1–12 selecionar • ESC voltar", {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 70, 912, 2, 0x1f2937).setOrigin(0,0);

    this.visible = 12;
    this.scroll = 0;
    this.sel = 0;

    this.renderList();

    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
    this.input.keyboard.on("keydown-UP", ()=>{ this.scroll = clamp(this.scroll-1, 0, Math.max(0, TechniqueDB.length-this.visible)); this.renderList(); });
    this.input.keyboard.on("keydown-DOWN", ()=>{ this.scroll = clamp(this.scroll+1, 0, Math.max(0, TechniqueDB.length-this.visible)); this.renderList(); });
    this.input.keyboard.on("keydown-ENTER", ()=> this.toggleEquip());
    this.input.keyboard.on("keydown", (e)=>{
      const n = parseInt(e.key,10);
      if(n>=1 && n<=this.visible){ this.sel = n-1; this.renderList(); }
    });
  }

  toggleEquip(){
    const s = GameStateSingleton.save;
    const idx = this.scroll + this.sel;
    const t = TechniqueDB[idx];
    const load = s.player.loadout.active;
    const pos = load.indexOf(t.id);
    if(pos>=0) load.splice(pos,1);
    else { if(load.length>=8) load.pop(); load.push(t.id); }
    saveGame(s);
    this.renderList();
  }

  renderList(){
    if(this.items) this.items.forEach(o=>o.destroy());
    this.items = [];

    const s = GameStateSingleton.save;
    const y0 = 86;

    for(let i=0;i<this.visible;i++){
      const idx = this.scroll + i;
      if(idx >= TechniqueDB.length) break;
      const t = TechniqueDB[idx];
      const ts = s.tech[t.id];
      const unlocked = s.player.belt >= t.minBelt;
      const inLoadout = s.player.loadout.active.includes(t.id);

      const y = y0 + i*34;
      const bg = this.add.rectangle(30, y, 900, 30, unlocked ? 0x111827 : 0x0b1220).setOrigin(0,0);
      bg.setStrokeStyle(1, (i===this.sel)?0xf59e0b:0x374151, 1);
      this.items.push(bg);

      const ic = this.add.rectangle(38, y+6, 18, 18, unlocked?0x60a5fa:0x334155).setOrigin(0,0);
      this.items.push(ic);

      const label = `${i+1}. ${t.name} [${t.mode}] • ${t.cat} • ${t.pos}`;
      const txt = this.add.text(62, y+7, label, {fontSize:"13px", color: unlocked? "#e8eef6":"#6b7280"});
      this.items.push(txt);

      const rate = ts.tries>0 ? Math.round((ts.perfect/ts.tries)*100) : 0;
      const right = `${inLoadout? "EQUIPADO":"—"} • LVL ${ts.lvl} • XP ${ts.xp} • Timing ${rate}%`;
      const rt = this.add.text(920, y+7, right, {fontSize:"13px", color: inLoadout? "#f59e0b":"#b7c2d2"}).setOrigin(1,0);
      this.items.push(rt);
    }

    if(this.loadPanel) this.loadPanel.forEach(o=>o.destroy());
    this.loadPanel = [];
    const py = 520;
    const r = this.add.rectangle(24, py-26, 912, 42, 0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);
    this.loadPanel.push(r);
    this.loadPanel.push(this.add.text(34, py-18, "LOADOUT (8):", {fontSize:"13px", color:"#b7c2d2"}));
    const names = s.player.loadout.active.map(id=> techDef(id)?.name || id);
    this.loadPanel.push(this.add.text(120, py-18, names.join(" • "), {fontSize:"13px", color:"#e8eef6"}));
  }
  update(){
    if(MobileInput.consume(this,'ESC')) this.scene.start('menu');
    if(MobileInput.consume(this,'ENTER')) this.toggleEquip();
    if(MobileInput.consume(this,'A')){ this.scroll = clamp(this.scroll-1, 0, Math.max(0, TechniqueDB.length-this.visible)); this.renderList(); }
    if(MobileInput.consume(this,'D')){ this.scroll = clamp(this.scroll+1, 0, Math.max(0, TechniqueDB.length-this.visible)); this.renderList(); }
  }
}

class TeamSelectScene extends Phaser.Scene {
  constructor(){ super("team_select"); }
  create(){
    this.add.text(24, 20, "Escolha de Equipe (classe)", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "1–4 escolher • ESC voltar", {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 70, 912, 2, 0x1f2937).setOrigin(0,0);

    const keys = Object.keys(Teams);
    let y = 92;
    keys.forEach((k, i)=>{
      const tm = Teams[k];
      this.add.rectangle(30, y, 900, 90, 0x111827).setOrigin(0,0).setStrokeStyle(1,0x374151,1);
      const c0 = parseInt(tm.colors[0].replace("#","0x"));
      this.add.rectangle(44, y+16, 22, 22, c0).setOrigin(0,0);
      this.add.text(74, y+14, `${i+1}. ${tm.name}`, {fontSize:"18px", color:"#e8eef6"});
      const b = tm.bonus;
      const lines = [];
      if(b.takedown) lines.push(`+Quedas`);
      if(b.sweep) lines.push(`+Raspagens`);
      if(b.pressure||b.pass) lines.push(`+Pressão/Passe`);
      if(b.giGrip) lines.push(`+Pegada GI`);
      if(b.back) lines.push(`+Costas`);
      if(b.sub) lines.push(`+Finalização`);
      if(b.iq) lines.push(`+Fight IQ`);
      const desc = `Bônus: ${lines.join(" • ")}  |  Afeta chance/custo/XP das técnicas sinérgicas.`;
      this.add.text(74, y+44, desc, {fontSize:"13px", color:"#b7c2d2"});
      y += 104;
    });

    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
    this.input.keyboard.on("keydown", (e)=>{
      const n = parseInt(e.key,10);
      if(n>=1 && n<=keys.length){
        GameStateSingleton.save.player.team = keys[n-1];
        saveGame(GameStateSingleton.save);
        this.scene.start("menu");
      }
    });
  }
}

class AcademyScene extends Phaser.Scene {
  constructor(){ super("academy"); }
  create(){
    this.add.text(24, 20, "Academia (Treino)", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "SPACE: drill • T: trocar técnica • ESC voltar", {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 70, 912, 2, 0x1f2937).setOrigin(0,0);

    this.add.rectangle(40, 96, 880, 420, 0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);
    for(let y=110;y<500;y+=28){
      for(let x=60;x<900;x+=56){
        this.add.rectangle(x, y, 52, 24, 0x1f4b99).setOrigin(0,0).setAlpha(0.65).setStrokeStyle(1,0x0b1220,0.35);
      }
    }

    const s = GameStateSingleton.save;
    this.techIndex = 0;
    this.pickFirstUsable();

    this.statusText = this.add.text(50, 488, "", {fontSize:"14px", color:"#e8eef6"});
    this.updateTechText();

    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
    this.input.keyboard.on("keydown-T", ()=>{ this.nextTech(); this.updateTechText(); });
    this.input.keyboard.on("keydown-SPACE", ()=>{ if(!this.inDrill) this.startDrill(); });

    this.inDrill = false;
    this.zone = {x: 200, w: 560};
  }

  pickFirstUsable(){
    const s = GameStateSingleton.save;
    const usable = TechniqueDB.filter(t=>s.player.belt>=t.minBelt);
    this.techIndex = TechniqueDB.indexOf(usable[0] || TechniqueDB[0]);
  }
  nextTech(){
    const s = GameStateSingleton.save;
    let tries = 0;
    do{
      this.techIndex = (this.techIndex + 1) % TechniqueDB.length;
      tries++;
      if(tries>TechniqueDB.length) break;
    }while(s.player.belt < TechniqueDB[this.techIndex].minBelt);
  }

  updateTechText(){
    const s = GameStateSingleton.save;
    const t = TechniqueDB[this.techIndex];
    const st = s.tech[t.id];
    const rate = st.tries>0 ? Math.round((st.perfect/st.tries)*100) : 0;
    this.statusText.setText(
      `Técnica: ${t.name} [${t.mode}] • ${t.cat} • ${t.pos}   |   LVL ${st.lvl} XP ${st.xp} • Timing ${rate}%\n`+
      `Drill: aperte SPACE e depois SPACE quando o marcador entrar na zona verde.`
    );
  }

  startDrill(){
    this.inDrill = true;
    const s = GameStateSingleton.save;
    const t = TechniqueDB[this.techIndex];

    this.bar = this.add.rectangle(this.zone.x, 420, this.zone.w, 18, 0x111827).setOrigin(0,0).setStrokeStyle(1,0x374151,1);
    const okW = 110;
    const okX = this.zone.x + 80 + Math.floor(rnd()*(this.zone.w-okW-160));
    this.okZone = this.add.rectangle(okX, 420, okW, 18, 0x16a34a).setOrigin(0,0).setAlpha(0.7);

    this.indicator = this.add.rectangle(this.zone.x, 416, 6, 26, 0xf59e0b).setOrigin(0,0);
    this.indSpeed = 420 + s.player.stats.iq * 4 + (s.story.satoshi.kuzushi*12);
    this.indDir = 1;

    this.resultText = this.add.text(200, 450, "Pressione SPACE no timing certo!", {fontSize:"14px", color:"#b7c2d2"});

    this.input.keyboard.once("keydown-SPACE", ()=>{
      const x = this.indicator.x;
      const okMin = this.okZone.x;
      const okMax = this.okZone.x + this.okZone.width;
      const hit = (x>=okMin && x<=okMax);

      let xp = hit ? 32 : 12;
      const team = teamObj();
      if(t.tags.includes("takedown") && (team.bonus.takedown||0)>0) xp += 4;
      if(t.tags.includes("sweep") && (team.bonus.sweep||0)>0) xp += 4;
      if((t.tags.includes("pressure")||t.tags.includes("pass")) && ((team.bonus.pressure||0)+(team.bonus.pass||0))>0) xp += 4;
      if(t.tags.includes("giGrip") && (team.bonus.giGrip||0)>0) xp += 4;
      if(t.tags.includes("back") && (team.bonus.back||0)>0) xp += 4;

      addTechXP(t.id, xp);
      recordDrill(t.id, hit);
      maybeBeltUp();
      maybeUnlockAleluyopolis();
      saveGame(s);

      this.resultText.setText(hit ? `✅ Drill PERFEITO! +${xp} XP` : `🟡 Quase! +${xp} XP`);
      this.time.delayedCall(700, ()=>{
        this.bar?.destroy(); this.okZone?.destroy(); this.indicator?.destroy(); this.resultText?.destroy();
        this.bar=null; this.okZone=null; this.indicator=null; this.resultText=null;
        this.inDrill=false;
        this.updateTechText();
      });
    });
  }

  update(time, dt){
    if(!this.inDrill || !this.indicator) return;
    const step = (this.indSpeed * dt/1000) * this.indDir;
    this.indicator.x += step;
    if(this.indicator.x <= this.zone.x){ this.indicator.x = this.zone.x; this.indDir = 1; }
    if(this.indicator.x >= this.zone.x + this.zone.w - 6){ this.indicator.x = this.zone.x + this.zone.w - 6; this.indDir = -1; }
  }
}

// Enemy archetype helper
function enemyArchetype(mode){
  const types = [
    {name:"Passador Pressão", bias:{pass:0.25, pressure:0.25, takedown:0.10, sweep:0.05, back:0.10, sub:0.15}},
    {name:"Guarda Raspador", bias:{sweep:0.30, sub:0.20, pass:0.05, takedown:0.05, back:0.10, pressure:0.05}},
    {name:"Wrestler Quedador", bias:{takedown:0.35, pressure:0.10, pass:0.10, sweep:0.05, sub:0.10}},
    {name:"Caçador de Costas", bias:{back:0.30, sub:0.20, pass:0.10, takedown:0.10}},
  ];
  const mma = [
    {name:"Boxeador Pesado", bias:{strike:0.35, takedown:0.10, control:0.10, sub:0.08}},
    {name:"Grappler MMA", bias:{strike:0.10, takedown:0.25, control:0.20, sub:0.15}},
    {name:"Wrestler Cage", bias:{strike:0.12, takedown:0.30, control:0.20}},
  ];
  if(mode==="MMA_CAGE") return mma[Math.floor(rnd()*mma.length)];
  return types[Math.floor(rnd()*types.length)];
}

class FightScene extends Phaser.Scene {
  constructor(key, mode){ super(key); this.mode = mode; }

  create(){
    const s = GameStateSingleton.save;
    this.isOfficial = (this.mode==="GI");
    this.isSand = (this.mode==="NO_GI_SAND");
    this.isMMA = (this.mode==="MMA_CAGE");
    this.isAleluyopolis = (this.mode==="ALELUYOPOLIS");

    const title = this.isAleluyopolis ? "Aleluyopolis — Abu Dhabi" :
      this.isMMA ? "MMA Cage (protótipo)" :
      this.isOfficial ? "Campeonato Oficial (GI)" : "Submundo NO-GI (Areia)";

    this.add.text(24, 18, title, {fontSize:"20px", color:"#e8eef6"});
    const subtitle = this.isOfficial ? "Pontos + estabilização 3s • vitória por pontos/finalização"
      : this.isMMA ? "Compostura + controle • ground game decide • protótipo"
      : this.isAleluyopolis ? "Invitational internacional • bolsa alta • oponentes duros"
      : "Dominância + finalização • areia drena gás • bolsa maior (Heat sobe)";
    this.add.text(24, 44, subtitle, {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 68, 912, 2, 0x1f2937).setOrigin(0,0);

    this.add.rectangle(40, 92, 880, 420, 0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);

    if(this.isOfficial){
      for(let y=110;y<500;y+=28){
        for(let x=60;x<900;x+=56){
          this.add.rectangle(x, y, 52, 24, 0x1f4b99).setOrigin(0,0).setAlpha(0.65).setStrokeStyle(1,0x0b1220,0.35);
        }
      }
    } else if(this.isSand || this.isAleluyopolis){
      for(let y=110;y<500;y+=18){
        for(let x=60;x<900;x+=36){
          const a = 0.12 + rnd()*0.08;
          this.add.rectangle(x, y, 32, 14, 0xd7c29e).setOrigin(0,0).setAlpha(a);
        }
      }
      if(this.isSand){
        this.add.rectangle(820, 104, 90, 28, 0x111827).setOrigin(0,0).setStrokeStyle(1,0x374151,1);
        this.add.text(826, 109, "💰🎲", {fontSize:"14px"});
      }
      if(this.isAleluyopolis){
        this.add.rectangle(70, 104, 120, 26, 0x111827).setOrigin(0,0).setStrokeStyle(1,0x374151,1);
        this.add.rectangle(76, 110, 18, 14, 0xf59e0b).setOrigin(0,0).setAlpha(0.8);
        this.add.text(100, 109, "🏜️", {fontSize:"14px"});
      }
    } else if(this.isMMA){
      this.add.rectangle(90, 116, 820, 370, 0x0b1220).setOrigin(0,0).setAlpha(0.35);
      for(let i=0;i<10;i++){
        this.add.rectangle(90+i*82, 110, 2, 390, 0x334155).setOrigin(0,0).setAlpha(0.25);
      }
      this.add.rectangle(60, 104, 90, 26, 0x111827).setOrigin(0,0).setStrokeStyle(1,0x374151,1);
      this.add.text(68, 109, "⛓️", {fontSize:"14px"});
    }

    const g = this.add.graphics();
    g.fillStyle(0xe8eef6, 1); g.fillRect(0,0,10,10); g.fillStyle(0x111827, 1); g.fillRect(3,3,4,4);
    g.generateTexture("pF", 10,10);
    g.clear();
    g.fillStyle(0xf59e0b, 1); g.fillRect(0,0,10,10); g.fillStyle(0x111827, 1); g.fillRect(3,3,4,4);
    g.generateTexture("eF", 10,10);
    g.destroy();

    this.pSprite = this.add.image(340, 320, "pF").setScale(2);
    this.eSprite = this.add.image(620, 320, "eF").setScale(2);

    this.timeLeft = this.isOfficial ? 300 : (this.isMMA ? 180 : 180);
    this.phase = "FIGHT";
    this.posState = "STAND";
    this.pending = null;

    this.p = { composure: 100, stamina: 100, posture: 100, dominance: 0, score:0, adv:0, pen:0, flow:0, stalls:0 };
    this.e = { composure: 100, stamina: 100, posture: 100, dominance: 0, score:0, adv:0, pen:0, flow:0 };

    this.enemyType = enemyArchetype(this.isMMA?"MMA_CAGE":(this.isAleluyopolis?"NO_GI":"BJJ"));
    this.enemyLabel = this.add.text(24, 510, `Oponente: ${this.enemyType.name}`, {fontSize:"13px", color:"#b7c2d2"});

    this.hud = this.add.graphics();
    this.hudText = this.add.text(500, 20, "", {fontSize:"14px", color:"#e8eef6"});
    this.actionText = this.add.text(500, 44, "", {fontSize:"13px", color:"#b7c2d2"});
    this.logText = this.add.text(500, 68, "", {fontSize:"13px", color:"#b7c2d2"});
    this.logLines = [];

    this.subUI = this.add.graphics();
    this.subText = this.add.text(56, 90, "", {fontSize:"14px", color:"#e8eef6"}).setDepth(30);

    this.input.keyboard.on("keydown-ESC", ()=> this.endFight("exit"));
    this.input.keyboard.on("keydown", (e)=> this.onKey(e));

    this.buildActionSet();
    this.updateHUD();
  }

  log(msg){
    this.logLines.unshift(msg);
    if(this.logLines.length>3) this.logLines.pop();
    this.logText.setText(this.logLines.join("\n"));
  }

  onKey(e){
    if(this.phase!=="FIGHT") return;
    if(["1","2","3","4"].includes(e.key)){
      const a = this.actions[parseInt(e.key,10)-1];
      this.resolveAction(a);
    }
  }

  buildActionSet(){
    const s = GameStateSingleton.save;
    const mode = this.mode;
    const load = s.player.loadout.active.slice();
    const usable = load.filter(id=> canUseTech(id, mode==="ALELUYOPOLIS"?"NO_GI_SAND":mode));
    const pickFirst = (cat)=> usable.find(id=> techDef(id)?.cat===cat) || usable[0];

    if(this.posState==="STAND"){
      if(this.isMMA){
        this.actions = [
          {label:`Jab-Cross`, type:"TECH", tech:"jab_cross"},
          {label:`Chute Baixo`, type:"TECH", tech:"low_kick"},
          {label:`Clinch na Grade`, type:"TECH", tech:"cage_clinch"},
          {label:`Entrada de Queda`, type:"TECH", tech:"single_leg"},
        ];
      }else{
        this.actions = [
          {label:`${techDef(pickFirst("Queda"))?techDef(pickFirst("Queda")).name:"Entrar Queda"}`, type:"TECH", tech: pickFirst("Queda") || "single_leg" },
          {label:`${techDef(pickFirst("Transição"))?techDef(pickFirst("Transição")).name:"Clinch"}`, type:"TECH", tech: pickFirst("Transição") || "snapdown_fh" },
          {label:`Medir / Feint`, type:"FEINT"},
          {label:`Respirar`, type:"REST"},
        ];
      }
    } else if(this.posState==="CLINCH"){
      this.actions = this.isMMA ? [
        {label:"Quebra de clinch", type:"BREAK"},
        {label:"Pressão na grade", type:"PRESSURE"},
        {label:"Queda do clinch", type:"TECH", tech:"body_lock_trip"},
        {label:"Respirar", type:"REST"},
      ] : [
        {label:`Queda`, type:"TECH", tech: usable.find(id=>techDef(id)?.cat==="Queda") || "body_lock_trip"},
        {label:`Quebrar Pegada`, type:"BREAK"},
        {label:`Empurrar/Pressão`, type:"PRESSURE"},
        {label:`Respirar`, type:"REST"},
      ];
    } else if(this.posState==="GUARD_BOTTOM" || this.posState==="HALF_BOTTOM"){
      this.actions = [
        {label:`Raspagem`, type:"TECH", tech: usable.find(id=>techDef(id)?.cat==="Raspagem") || "half_uh_sweep"},
        {label:`Finalização`, type:"TECH", tech: usable.find(id=>techDef(id)?.cat==="Finalização") || "triangle"},
        {label:`Recompor Guarda`, type:"RETAIN"},
        {label:`Levantar Técnico`, type:"STANDUP"},
      ];
    } else if(this.posState==="GUARD_TOP" || this.posState==="HALF_TOP"){
      this.actions = [
        {label:`Passar`, type:"TECH", tech: usable.find(id=>techDef(id)?.cat==="Passagem") || "knee_slice"},
        {label:`Ajustar Base`, type:"BASE"},
        {label:`Pressão`, type:"PRESSURE"},
        {label:`Respirar`, type:"REST"},
      ];
    } else if(this.posState==="SIDE_TOP"){
      this.actions = [
        {label:`Controle`, type:"TECH", tech:"knee_on_belly"},
        {label:`Ir pra Montada`, type:"TO_MOUNT"},
        {label:`Pegar Costas`, type:"TECH", tech:"back_take"},
        {label:`Finalização`, type:"TECH", tech:(this.isOfficial ? "cross_collar" : "arm_triangle")},
      ];
    } else if(this.posState==="MOUNT_TOP"){
      this.actions = [
        {label:`Manter Montada`, type:"TECH", tech:"mount_stable"},
        {label:`Finalização`, type:"TECH", tech:(this.isOfficial ? "cross_collar" : "armbar")},
        {label:`Ir pra Costas`, type:"TO_BACK"},
        {label:`Respirar`, type:"REST"},
      ];
    } else if(this.posState==="BACK_TOP"){
      this.actions = [
        {label:`Seatbelt`, type:"TECH", tech:"seatbelt"},
        {label:`Finalização`, type:"TECH", tech:(this.isOfficial ? "bow_arrow" : "rnc")},
        {label:`Ajustar ganchos`, type:"HOOKS"},
        {label:`Respirar`, type:"REST"},
      ];
    } else if(this.posState==="FRONT_HEADLOCK"){
      this.actions = [
        {label:`Guilhotina`, type:"TECH", tech:"guillotine"},
        {label:`Ir pra Side`, type:"TO_SIDE"},
        {label:`Pressão`, type:"PRESSURE"},
        {label:`Respirar`, type:"REST"},
      ];
    } else {
      this.actions = [
        {label:"Respirar", type:"REST"},
        {label:"Pressão", type:"PRESSURE"},
        {label:"Base", type:"BASE"},
        {label:"Feint", type:"FEINT"},
      ];
    }
    this.updateActionText();
  }

  updateActionText(){
    const labels = this.actions.map((a,i)=> `${i+1}:${a.label}`).join("   ");
    this.actionText.setText(`POSIÇÃO: ${this.posState}  |  Ações: ${labels}`);
  }

  startPending(points, pos, who="p"){
    if(!this.isOfficial) return;
    this.pending = { who, points, pos, tHeld:0, awarded:false };
  }
  tickPending(dt){
    if(!this.pending || this.pending.awarded) return;
    const curPos = this.posState;
    if(curPos !== this.pending.pos){
      this.pending = null; return;
    }
    this.pending.tHeld += dt/1000;
    if(this.pending.tHeld >= 3.0){
      if(this.pending.who==="p"){
        this.p.score += this.pending.points;
        this.p.adv += 1;
        this.log(`🏆 Pontos +${this.pending.points} (estabilizou 3s)`);
      }else{
        this.e.score += this.pending.points;
      }
      this.pending.awarded = true;
      this.pending = null;
    }
  }

  enemyTurn(){
    const b = this.enemyType.bias;
    let pick = null;
    if(this.isMMA){
      if(this.posState==="STAND"){
        pick = rnd() < (b.strike||0.2) ? "jab_cross" : "single_leg";
      }else{
        pick = "PRESSURE";
      }
    }else{
      if(this.posState==="STAND") pick = rnd()<0.55 ? "single_leg" : "snapdown_fh";
      else if(this.posState==="GUARD_TOP"||this.posState==="HALF_TOP") pick = "knee_slice";
      else if(this.posState==="GUARD_BOTTOM"||this.posState==="HALF_BOTTOM") pick = "half_uh_sweep";
      else if(this.posState==="FRONT_HEADLOCK") pick = "guillotine";
      else pick = rnd()<0.25 ? "back_take" : "PRESSURE";
    }

    if(pick==="PRESSURE"){
      return {ok:true, generic:"PRESSURE", msg:"Oponente aumenta a pressão."};
    }

    const t = techDef(pick);
    if(!t) return {ok:false, msg:"Oponente mede o jogo."};

    const chance = clamp(t.base + (rnd()*0.1-0.05), 0.15, 0.85);
    const cost = Math.round(t.stam * (this.isSand?1.12:1));
    this.e.stamina = clamp(this.e.stamina - cost*0.55, 0, 100);

    const ok = rnd() < chance;
    return {ok, tech:pick, msg: ok? `Oponente encaixa ${t.name}.` : `Oponente tenta ${t.name}, falha.`};
  }

  applyEnemy(er){
    if(!er) return;
    if(er.generic==="PRESSURE"){
      this.p.composure = clamp(this.p.composure - 4, 0, 100);
      this.e.dominance = clamp(this.e.dominance + 4, 0, 100);
      this.log(er.msg);
      return;
    }
    if(!er.tech) return;
    const t = techDef(er.tech);
    if(!t) return;

    if(er.ok){
      if(t.cat==="Queda"){
        this.posState = rnd()<0.55 ? "GUARD_BOTTOM" : "HALF_BOTTOM";
        this.e.dominance = clamp(this.e.dominance + 8, 0, 100);
        this.p.posture = clamp(this.p.posture - 10, 0, 100);
        if(this.isOfficial) this.startPending(2, this.posState, "e");
      } else if(t.cat==="Raspagem"){
        this.posState = rnd()<0.6 ? "GUARD_BOTTOM" : "HALF_BOTTOM";
        if(this.isOfficial) this.startPending(2, this.posState, "e");
      } else if(t.cat==="Passagem"){
        this.posState = "SIDE_TOP";
        this.p.composure = clamp(this.p.composure - 6, 0, 100);
        this.e.dominance = clamp(this.e.dominance + 10, 0, 100);
        if(this.isOfficial) this.startPending(3, "SIDE_TOP", "e");
      } else if(t.cat==="Finalização"){
        this.startSubmission(er.tech, true);
      } else if(t.cat==="Transição" && t.id==="snapdown_fh"){
        this.posState = "FRONT_HEADLOCK";
        this.p.posture = clamp(this.p.posture - 8, 0, 100);
        this.e.dominance = clamp(this.e.dominance + 6, 0, 100);
      } else if(t.cat==="Striking"){
        this.p.composure = clamp(this.p.composure - 8, 0, 100);
      }
      this.log(er.msg);
    } else {
      this.log(er.msg);
    }
  }

  startSubmission(techId, enemyInitiated=false){
    this.phase = "SUBMISSION";
    this.sub = {
      byEnemy: enemyInitiated,
      techId,
      atk: 50,
      def: 50,
      timer: 8.0,
      ptr: 0,
      dir: 1,
      zoneX: 0.45 + rnd()*0.1,
      zoneW: 0.18
    };

    const posBonus = (this.posState==="BACK_TOP"||this.posState==="MOUNT_TOP") ? 12 : 6;
    this.sub.atk += posBonus;
    this.sub.def -= 4;

    this.log(`⚠️ Tentativa de finalização: ${techDef(techId)?.name || techId}. SPACE no timing!`);
    this.updateHUD();

    const press = ()=> this.resolveSubmissionInput();
    this.input.keyboard.once("keydown-SPACE", ()=>{
      press();
      if(this.phase==="SUBMISSION"){
        this.input.keyboard.once("keydown-SPACE", ()=>{
          press();
          if(this.phase==="SUBMISSION"){
            this.input.keyboard.once("keydown-SPACE", press);
          }
        });
      }
    });
  }

  resolveSubmissionInput(){
    if(this.phase!=="SUBMISSION") return;
    const zMin = this.sub.zoneX;
    const zMax = this.sub.zoneX + this.sub.zoneW;
    const p = this.sub.ptr;
    const hit = (p>=zMin && p<=zMax);

    if(this.sub.byEnemy){
      this.p.stamina = clamp(this.p.stamina - 10*(this.isSand?1.1:1), 0, 100);
      if(hit){ this.sub.def += 18; this.sub.atk -= 12; this.log("✅ Defesa no timing: janela de escape!"); }
      else { this.sub.def -= 8; this.sub.atk += 10; this.log("❌ Defesa fora do timing: pressão aumenta!"); }
    }else{
      this.p.stamina = clamp(this.p.stamina - 10*(this.isSand?1.1:1), 0, 100);
      if(hit){ this.sub.atk += 18; this.sub.def -= 12; this.log("✅ Ajuste perfeito: finalização aperta!"); }
      else { this.sub.atk -= 6; this.sub.def += 8; this.log("❌ Ajuste ruim: rival respira e defende!"); }
    }
    this.sub.atk = clamp(this.sub.atk, 0, 100);
    this.sub.def = clamp(this.sub.def, 0, 100);
    this.updateHUD();
  }

  resolveAction(action){
    const s = GameStateSingleton.save;
    if(this.phase!=="FIGHT") return;

    const restPenalty = ()=>{
      if(!this.isOfficial) return;
      this.p.stalls += 1;
      if(this.p.stalls>=4){
        this.p.pen += 1;
        this.p.stalls = 0;
        this.log("⚠️ Penalidade por falta de combatividade.");
        s.story.suspicion = clamp(s.story.suspicion + 3, 0, 100);
      }
    };

    if(action.type==="REST"){
      this.p.stamina = clamp(this.p.stamina + 10, 0, 100);
      this.p.posture = clamp(this.p.posture + 6, 0, 100);
      this.p.flow = clamp(this.p.flow - 2, 0, 100);
      this.log("Você respira e recupera gás/base.");
      restPenalty();
      this.applyEnemy(this.enemyTurn());
      this.buildActionSet(); this.updateHUD(); this.checkEnd();
      return;
    }

    if(action.type==="FEINT"){
      this.p.stamina = clamp(this.p.stamina - 4, 0, 100);
      this.p.flow = clamp(this.p.flow + 6, 0, 100);
      this.e.posture = clamp(this.e.posture - 4, 0, 100);
      this.log("Você mede e dá a isca. Flow sobe.");
      this.applyEnemy(this.enemyTurn());
      this.updateHUD(); this.checkEnd();
      return;
    }

    if(action.type==="TO_MOUNT"){ this.tryTransition("MOUNT_TOP", "Ir pra montada"); }
    else if(action.type==="TO_BACK"){ this.tryTransition("BACK_TOP", "Ir pra costas"); }
    else if(action.type==="TO_SIDE"){ this.tryTransition("SIDE_TOP", "Ir pra side"); }
    else if(action.type==="RETAIN"){ this.tryRetain(); }
    else if(action.type==="STANDUP"){ this.tryStandup(); }
    else if(action.type==="PRESSURE"){ this.applyPressure(); }
    else if(action.type==="BREAK"){ this.tryBreak(); }
    else if(action.type==="BASE"){
      this.p.posture = clamp(this.p.posture + 12, 0, 100);
      this.p.stamina = clamp(this.p.stamina - 6*(this.isSand?1.1:1), 0, 100);
      this.log("Você ajusta base e postura.");
    }
    else if(action.type==="HOOKS"){
      this.p.stamina = clamp(this.p.stamina - 6, 0, 100);
      this.p.dominance = clamp(this.p.dominance + 6, 0, 100);
      this.log("Você ajusta ganchos e controla mais.");
    }
    else if(action.type==="TECH"){ this.useTechnique(action.tech); }

    if(this.phase==="FIGHT"){
      this.applyEnemy(this.enemyTurn());
      this.buildActionSet(); this.updateHUD(); this.checkEnd();
    }
  }

  useTechnique(id){
    const s = GameStateSingleton.save;
    const mode = this.mode==="ALELUYOPOLIS" ? "NO_GI_SAND" : this.mode;
    const t = techDef(id);
    if(!t){ this.log("Ação inválida."); return; }
    if(!canUseTech(id, mode)){ this.log(`Técnica bloqueada: ${t.name}`); return; }

    const cost = techStaminaCost(id, mode);
    if(this.p.stamina < cost){
      this.log("Sem gás pra forçar isso. Perde base.");
      this.p.posture = clamp(this.p.posture - 8, 0, 100);
      this.p.flow = clamp(this.p.flow - 6, 0, 100);
      return;
    }
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);

    let chance = techSuccessChance(id, mode);
    chance += (this.p.flow/100) * 0.12;
    chance += (this.p.posture - this.e.posture) * 0.0012;
    if(this.isSand && t.cat==="Queda") chance -= 0.04;
    chance = clamp(chance, 0.12, 0.92);

    const ok = rnd() < chance;
    addTechXP(id, ok ? 18 : 10);
    maybeBeltUp();
    maybeUnlockAleluyopolis();
    saveGame(s);

    if(ok){
      this.p.flow = clamp(this.p.flow + 10, 0, 100);
      this.log(`✅ ${t.name} encaixou!`);
      this.applyTechSuccess(t);
    }else{
      this.p.flow = clamp(this.p.flow - 8, 0, 100);
      this.p.posture = clamp(this.p.posture - 6, 0, 100);
      this.e.flow = clamp(this.e.flow + 6, 0, 100);
      this.log(`❌ ${t.name} falhou — abre contra.`);
      if(this.isOfficial && rnd()<0.15){ this.p.adv += 1; this.log("⭐ Quase! Advantage."); }
    }
  }

  applyTechSuccess(t){
    if(t.cat==="Queda"){
      this.posState = rnd()<0.55 ? "GUARD_TOP" : "HALF_TOP";
      this.p.dominance = clamp(this.p.dominance + 8, 0, 100);
      this.e.posture = clamp(this.e.posture - 10, 0, 100);
      if(this.isOfficial) this.startPending(2, this.posState);
    } else if(t.cat==="Raspagem"){
      this.posState = rnd()<0.60 ? "GUARD_TOP" : "HALF_TOP";
      this.p.dominance = clamp(this.p.dominance + 8, 0, 100);
      this.e.posture = clamp(this.e.posture - 8, 0, 100);
      if(this.isOfficial) this.startPending(2, this.posState);
    } else if(t.cat==="Passagem"){
      this.posState = "SIDE_TOP";
      this.p.dominance = clamp(this.p.dominance + 10, 0, 100);
      this.e.composure = clamp(this.e.composure - 6, 0, 100);
      if(this.isOfficial) this.startPending(3, "SIDE_TOP");
    } else if(t.cat==="Controle"){
      if(t.id==="knee_on_belly"){
        this.p.dominance = clamp(this.p.dominance + 8, 0, 100);
        this.e.composure = clamp(this.e.composure - 9, 0, 100);
        if(this.isOfficial) this.startPending(2, "SIDE_TOP");
        this.posState = "SIDE_TOP";
      }
      if(t.id==="mount_stable"){
        this.posState="MOUNT_TOP";
        this.p.dominance = clamp(this.p.dominance + 10, 0, 100);
        if(this.isOfficial) this.startPending(4, "MOUNT_TOP");
      }
      if(t.id==="seatbelt"){
        this.posState="BACK_TOP";
        this.p.dominance = clamp(this.p.dominance + 8, 0, 100);
        if(this.isOfficial) this.startPending(4, "BACK_TOP");
      }
      if(t.id==="cage_clinch"){
        this.posState="CLINCH";
        this.p.dominance = clamp(this.p.dominance + 6, 0, 100);
        this.e.posture = clamp(this.e.posture - 6, 0, 100);
      }
    } else if(t.cat==="Transição"){
      if(t.id==="back_take"){
        this.posState="BACK_TOP";
        this.p.dominance = clamp(this.p.dominance + 14, 0, 100);
        if(this.isOfficial) this.startPending(4, "BACK_TOP");
      }
      if(t.id==="snapdown_fh"){
        this.posState="FRONT_HEADLOCK";
        this.p.dominance = clamp(this.p.dominance + 6, 0, 100);
        this.e.posture = clamp(this.e.posture - 10, 0, 100);
      }
      if(t.id==="guard_pull"){
        this.posState="GUARD_BOTTOM";
        this.p.dominance = clamp(this.p.dominance + 2, 0, 100);
      }
    } else if(t.cat==="Finalização"){
      this.startSubmission(t.id, false);
    } else if(t.cat==="Striking"){
      const dmg = t.id==="jab_cross" ? 9 : 7;
      this.e.composure = clamp(this.e.composure - dmg, 0, 100);
      this.e.posture = clamp(this.e.posture - 6, 0, 100);
      this.p.flow = clamp(this.p.flow + 4, 0, 100);
    }
  }

  tryTransition(next, label){
    const cost = 10*(this.isSand?1.12:1);
    if(this.p.stamina < cost){
      this.log(`Sem gás pra ${label}.`);
      this.p.posture = clamp(this.p.posture - 6, 0, 100);
      return;
    }
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);
    let chance = 0.52 + (this.p.flow/100)*0.10 + (this.p.posture-this.e.posture)*0.001;
    chance = clamp(chance, 0.15, 0.85);
    if(rnd()<chance){
      this.posState = next;
      this.p.flow = clamp(this.p.flow + 8, 0, 100);
      this.log(`✅ ${label} deu certo.`);
      if(this.isOfficial){
        if(next==="MOUNT_TOP") this.startPending(4, "MOUNT_TOP");
        if(next==="BACK_TOP") this.startPending(4, "BACK_TOP");
        if(next==="SIDE_TOP") this.startPending(3, "SIDE_TOP");
      }else{
        this.p.dominance = clamp(this.p.dominance + 10, 0, 100);
      }
    }else{
      this.p.flow = clamp(this.p.flow - 10, 0, 100);
      this.log(`❌ ${label} falhou.`);
    }
  }

  tryRetain(){
    const cost = 8*(this.isSand?1.1:1);
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);
    const chance = clamp(0.58 + (this.p.flow/100)*0.08 + (this.p.posture-this.e.posture)*0.0012, 0.2, 0.9);
    if(rnd()<chance){
      if(this.posState==="HALF_BOTTOM") this.posState="GUARD_BOTTOM";
      this.p.posture = clamp(this.p.posture + 8, 0, 100);
      this.log("✅ Você recompõe e trava o jogo.");
      this.p.flow = clamp(this.p.flow + 4, 0, 100);
    }else{
      this.log("❌ Tentou recompor, mas tomou pressão.");
      this.p.posture = clamp(this.p.posture - 8, 0, 100);
      this.e.dominance = clamp(this.e.dominance + 6, 0, 100);
    }
  }

  tryStandup(){
    const cost = 14*(this.isSand?1.12:1);
    if(this.p.stamina < cost){
      this.log("Sem gás pra levantar técnico.");
      this.p.posture = clamp(this.p.posture - 6, 0, 100);
      return;
    }
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);
    const chance = clamp(0.52 + (this.p.posture/100)*0.15 + (this.p.flow/100)*0.05, 0.15, 0.88);
    if(rnd()<chance){
      this.posState="STAND";
      this.log("✅ Você levantou e reiniciou no em pé.");
      this.p.flow = clamp(this.p.flow + 6, 0, 100);
    }else{
      this.log("❌ Tentou levantar, voltou pro chão pior.");
      this.posState="HALF_BOTTOM";
      this.p.posture = clamp(this.p.posture - 10, 0, 100);
      this.e.dominance = clamp(this.e.dominance + 8, 0, 100);
    }
  }

  applyPressure(){
    const cost = 10*(this.isSand?1.12:1);
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);
    const dmg = 6 + Math.floor(this.p.flow/25);
    this.e.composure = clamp(this.e.composure - dmg, 0, 100);
    this.p.dominance = clamp(this.p.dominance + 5, 0, 100);
    this.log(`Pressão: compostura do rival -${dmg}.`);
  }

  tryBreak(){
    const cost = 8;
    this.p.stamina = clamp(this.p.stamina - cost, 0, 100);
    const chance = clamp(0.60 + (this.p.posture-this.e.posture)*0.001, 0.2, 0.9);
    if(rnd()<chance){
      this.posState="STAND";
      this.log("✅ Você soltou e voltou pro em pé.");
      this.p.flow = clamp(this.p.flow + 4, 0, 100);
    }else{
      this.log("❌ Falhou em quebrar. Rival encosta mais.");
      this.e.dominance = clamp(this.e.dominance + 6, 0, 100);
    }
  }

  updateHUD(){
    this.hud.clear();
    const x = 40;
    const drawBar = (yy, val, color)=>{
      const w = 430, h = 10;
      this.hud.fillStyle(0x111827, 1); this.hud.fillRect(x, yy, w, h);
      this.hud.fillStyle(color, 1); this.hud.fillRect(x, yy, w*(val/100), h);
      this.hud.lineStyle(1, 0x374151, 1); this.hud.strokeRect(x, yy, w, h);
    };

    drawBar(96,  this.p.composure, 0x60a5fa);
    drawBar(112, this.p.stamina,   0x22c55e);
    drawBar(128, this.p.posture,   0xf59e0b);
    drawBar(144, this.p.dominance, 0xa78bfa);

    drawBar(176, this.e.composure, 0xf97316);
    drawBar(192, this.e.stamina,   0x22c55e);
    drawBar(208, this.e.posture,   0xf59e0b);
    drawBar(224, this.e.dominance, 0xa78bfa);

    const t = this.timeLeft;
    const mm = String(Math.floor(t/60)).padStart(2,"0");
    const ss = String(Math.floor(t%60)).padStart(2,"0");

    const modeLabel = this.isOfficial
      ? `PLACAR: Você ${this.p.score} x ${this.e.score} • Adv ${this.p.adv}/${this.e.adv} • Pen ${this.p.pen}/${this.e.pen}`
      : this.isMMA
        ? `MMA: Compostura Você ${Math.round(this.p.composure)} • Rival ${Math.round(this.e.composure)}`
        : `SUBMUNDO: Dominância Você ${Math.round(this.p.dominance)}% | Rival ${Math.round(this.e.dominance)}%`;

    this.hudText.setText(`${modeLabel}\nTEMPO: ${mm}:${ss} • Flow ${Math.round(this.p.flow)}%`);

    if(this.phase==="SUBMISSION") this.drawSubmissionOverlay();
    else { this.subUI.clear(); this.subText.setText(""); }
  }

  drawSubmissionOverlay(){
    this.subUI.clear();
    this.subUI.fillStyle(0x000000, 0.45);
    this.subUI.fillRect(40, 250, 880, 250);

    const bx = 70, bw = 420, bh = 14;
    const draw = (yy, val, col)=>{
      this.subUI.fillStyle(0x111827, 1); this.subUI.fillRect(bx, yy, bw, bh);
      this.subUI.fillStyle(col, 1); this.subUI.fillRect(bx, yy, bw*(val/100), bh);
      this.subUI.lineStyle(1, 0x374151, 1); this.subUI.strokeRect(bx, yy, bw, bh);
    };
    draw(292, this.sub.atk, 0xef4444);
    draw(328, this.sub.def, 0x22c55e);

    const tx = 540, ty = 292, tw = 320, th = 50;
    this.subUI.fillStyle(0x111827, 1); this.subUI.fillRect(tx, ty, tw, th);
    this.subUI.lineStyle(1, 0x374151, 1); this.subUI.strokeRect(tx, ty, tw, th);

    const zx = tx + tw*this.sub.zoneX;
    const zw = tw*this.sub.zoneW;
    this.subUI.fillStyle(0x16a34a, 0.65); this.subUI.fillRect(zx, ty, zw, th);

    const px = tx + tw*this.sub.ptr;
    this.subUI.fillStyle(0xf59e0b, 1); this.subUI.fillRect(px-3, ty-4, 6, th+8);

    const name = techDef(this.sub.techId)?.name || this.sub.techId;
    this.subText.setText(`FINALIZAÇÃO: ${name} • SPACE no timing (zona verde)`);
  }

  checkEnd(){
    if(this.p.composure<=0) this.endFight("loss");
    else if(this.e.composure<=0) this.endFight("win");
    else if(!this.isOfficial && !this.isMMA && this.p.dominance>=100 && this.e.composure<=30) this.endFight("dominance_win");
    else if(!this.isOfficial && !this.isMMA && this.e.dominance>=100 && this.p.composure<=30) this.endFight("dominance_loss");
  }

  endFight(result){
    const s = GameStateSingleton.save;
    if(result==="exit"){ this.scene.start("menu"); return; }

    let win = (result==="win"||result==="dominance_win");
    let label = win ? "VITÓRIA!" : "DERROTA!";

    const maybeEvidence = ()=>{
      if(this.isOfficial && !win){
        if(rnd()<0.45){
          const ev = ["📄 Chave de bracket suspeita", "🎙️ Áudio do promotor", "🧾 Lista de odds vazada", "📷 Foto do árbitro com cartola"][Math.floor(rnd()*4)];
          s.story.evidence.push(ev);
          s.story.suspicion = clamp(s.story.suspicion + 8, 0, 100);
          this.log("🕵️ Você conseguiu uma evidência.");
        } else {
          s.story.suspicion = clamp(s.story.suspicion + 2, 0, 100);
        }
      }
    };

    if(win){
      if(this.isOfficial){
        s.player.money += 90 + s.player.belt*20;
        s.player.respect += 8 + s.player.belt*2;
        s.player.honor += 2;
        s.story.chapter = Math.max(s.story.chapter, 2);
      }else if(this.isMMA){
        s.player.money += 140 + s.player.belt*30;
        s.player.respect += 4;
        s.player.stats.mma = clamp(s.player.stats.mma + 1, 0, 30);
        s.story.mmaRoute = true;
        s.story.chapter = Math.max(s.story.chapter, 3);
      }else if(this.isAleluyopolis){
        s.player.money += 600 + s.player.belt*120;
        s.player.respect += 18;
        s.player.honor += 2;
        s.story.aleluyopolisWins += 1;
        s.story.satoshiMet = true;
        s.story.chapter = Math.max(s.story.chapter, 5);
      }else{
        s.player.money += 220 + s.player.belt*35;
        s.player.heat += 8;
        s.player.leverage += 2;
        s.player.honor -= 1;
        s.story.chapter = Math.max(s.story.chapter, 3);
      }
    }else{
      if(this.isOfficial){
        s.player.money += 20;
        s.player.respect = clamp(s.player.respect - 2, 0, 999);
        maybeEvidence();
      }else if(this.isMMA){
        s.player.money += 40;
        s.player.stats.mma = clamp(s.player.stats.mma + 0.5, 0, 30);
      }else if(this.isAleluyopolis){
        s.player.money += 80;
        s.player.respect = clamp(s.player.respect - 2, 0, 999);
      }else{
        s.player.money += 60;
        s.player.heat += 6;
        s.player.honor -= 1;
      }
    }

    s.player.honor = clamp(s.player.honor, 0, 100);
    s.player.heat = clamp(s.player.heat, 0, 100);

    maybeBeltUp();
    maybeUnlockAleluyopolis();
    saveGame(s);

    this.add.rectangle(240, 150, 480, 270, 0x0b1220).setOrigin(0,0).setStrokeStyle(1,0x334155,1);
    this.add.text(270, 180, label, {fontSize:"30px", color:"#e8eef6"});
    const msg = this.isAleluyopolis
      ? "Abu Dhabi não perdoa. Ajuste teu jogo.\nENTER: menu"
      : this.isMMA
        ? "No cage, o chão decide.\nENTER: menu"
        : this.isOfficial
          ? "No oficial, pontuação exige domínio.\nENTER: menu"
          : "No submundo, grana vem com Heat.\nENTER: menu";
    this.add.text(270, 224, msg, {fontSize:"14px", color:"#b7c2d2", lineSpacing:6});
    this.input.keyboard.once("keydown-ENTER", ()=> this.scene.start("menu"));
  }

  update(time, dt){
    if(this.phase==="FIGHT"){
      this.timeLeft -= dt/1000;
      if(this.timeLeft<=0){
        if(this.isOfficial) this.endFight(this.p.score >= this.e.score ? "win":"loss");
        else this.endFight(this.p.composure >= this.e.composure ? "win":"loss");
        return;
      }

      this.tickPending(dt);

      const sand = (this.isSand || this.isAleluyopolis) ? 1.06 : 1.0;
      this.p.stamina = clamp(this.p.stamina - 0.03*sand, 0, 100);
      this.e.stamina = clamp(this.e.stamina - 0.03*sand, 0, 100);

      this.p.posture = clamp(this.p.posture + 0.02, 0, 100);
      this.e.posture = clamp(this.e.posture + 0.02, 0, 100);

      const strong = (this.posState==="MOUNT_TOP"||this.posState==="BACK_TOP"||this.posState==="SIDE_TOP");
      if(strong){
        this.p.dominance = clamp(this.p.dominance + 0.04*(sand), 0, 100);
        this.e.composure = clamp(this.e.composure - 0.03*(sand), 0, 100);
      }else{
        this.p.dominance = clamp(this.p.dominance - 0.03, 0, 100);
        this.e.dominance = clamp(this.e.dominance - 0.03, 0, 100);
      }

      const centerX = 480, centerY = 320;
      const o = ({
        STAND: [-140, 0, 140, 0],
        CLINCH:[-20, 0, 20, 0],
        GUARD_BOTTOM:[-10, 30, 10,-30],
        GUARD_TOP:[-10,-30, 10, 30],
        HALF_BOTTOM:[-20, 20, 20,-20],
        HALF_TOP:[-20,-20, 20, 20],
        SIDE_TOP:[-30,-10, 30, 10],
        MOUNT_TOP:[-10,-10, 10, 10],
        BACK_TOP:[-10,-10, 10, 10],
        FRONT_HEADLOCK:[-20, -10, 20, 10]
      })[this.posState] || [-120,0,120,0];

      this.pSprite.x = lerp(this.pSprite.x, centerX + o[0], 0.08);
      this.pSprite.y = lerp(this.pSprite.y, centerY + o[1], 0.08);
      this.eSprite.x = lerp(this.eSprite.x, centerX + o[2], 0.08);
      this.eSprite.y = lerp(this.eSprite.y, centerY + o[3], 0.08);

      this.updateHUD();
      this.checkEnd();
    } else if(this.phase==="SUBMISSION"){
      this.sub.timer -= dt/1000;
      const spd = 0.55 + ((this.isSand||this.isAleluyopolis)?0.08:0);
      this.sub.ptr += (dt/1000)*spd*this.sub.dir;
      if(this.sub.ptr<=0){ this.sub.ptr=0; this.sub.dir=1; }
      if(this.sub.ptr>=1){ this.sub.ptr=1; this.sub.dir=-1; }

      const atkAdv = (this.sub.atk - this.sub.def) * 0.03;
      if(this.sub.byEnemy){
        this.p.composure = clamp(this.p.composure - Math.max(0, atkAdv)*0.9, 0, 100);
        if(this.sub.def >= 90){
          this.phase="FIGHT";
          this.log("✅ Você escapou! Volta pro jogo.");
        }
      }else{
        this.e.composure = clamp(this.e.composure - Math.max(0, atkAdv)*0.9, 0, 100);
        if(this.sub.atk >= 90){
          this.e.composure = 0;
          this.phase="FIGHT";
        }
      }

      if(this.p.stamina<=0){ this.phase="FIGHT"; this.log("Sem gás: tentativa morreu."); }
      if(this.sub.timer<=0){ this.phase="FIGHT"; this.log("Tempo acabou. Volta pro jogo."); }

      this.updateHUD();
      this.checkEnd();
    }
  }
}

class FightOfficialScene extends FightScene { constructor(){ super("fight_official", "GI"); } }
class FightUndergroundScene extends FightScene { constructor(){ super("fight_underground", "NO_GI_SAND"); } }
class FightMMAScene extends FightScene { constructor(){ super("fight_mma", "MMA_CAGE"); } }
class FightAleluyopolisScene extends FightScene { constructor(){ super("fight_aleluyopolis", "ALELUYOPOLIS"); } }

class SatoshiCampScene extends Phaser.Scene {
  constructor(){ super("satoshi_camp"); }
  create(){
    const s = GameStateSingleton.save;
    if(!s.story.aleluyopolisUnlocked){ this.scene.start("menu"); return; }

    this.add.text(24, 20, "Camp do Mestre Satoshi", {fontSize:"20px", color:"#e8eef6"});
    this.add.text(24, 46, "Escolha 1 treino (cada compra dá passiva) • 1–4 • ESC voltar", {fontSize:"13px", color:"#b7c2d2"});
    this.add.rectangle(24, 70, 912, 2, 0x1f2937).setOrigin(0,0);

    this.add.rectangle(30, 90, 900, 420, 0x0f172a).setOrigin(0,0).setStrokeStyle(1,0x334155,1);

    const pass = s.story.satoshi;
    const lines = [
      `Status: Kuzushi ${pass.kuzushi} • Breath ${pass.breath} • Chain ${pass.chain} • Cold ${pass.cold}`,
      "",
      "Treinos:",
      "1) Kuzushi (desequilíbrio): +chance em quedas/transições",
      "2) Breath Control: -custo de stamina em técnicas",
      "3) Chain Mastery: +bônus de Flow e encadeamento",
      "4) Cold Mind: compostura cai mais devagar em finais",
      "",
      `Custo: $250 (você tem $${s.player.money})`
    ];
    this.add.text(54, 120, lines.join("\n"), {fontSize:"14px", color:"#b7c2d2", lineSpacing:6});

    this.input.keyboard.on("keydown-ESC", ()=> this.scene.start("menu"));
    this.input.keyboard.on("keydown", (e)=>{
      const n = parseInt(e.key,10);
      if(!(n>=1 && n<=4)) return;
      if(s.player.money < 250){ this.flash("Sem grana pro camp. Vai lutar/treinar."); return; }
      s.player.money -= 250;
      if(n===1) pass.kuzushi = clamp(pass.kuzushi + 1, 0, 5);
      if(n===2) pass.breath  = clamp(pass.breath  + 1, 0, 5);
      if(n===3) pass.chain   = clamp(pass.chain   + 1, 0, 5);
      if(n===4) pass.cold    = clamp(pass.cold    + 1, 0, 5);
      s.story.satoshiMet = true;
      saveGame(s);
      this.flash("✅ Treino concluído. Passiva aplicada.");
      this.scene.restart();
    });
  }
  flash(msg){
    const t = this.add.text(54, 470, msg, {fontSize:"14px", color:"#e8eef6"});
    this.time.delayedCall(900, ()=> t.destroy());
  }
}

config.scene = [
  BootScene, MenuScene, HubScene, AcademyScene,
  FightOfficialScene, FightUndergroundScene, FightMMAScene, FightAleluyopolisScene,
  JournalScene, CardsScene, TeamSelectScene, SatoshiCampScene
];

new Phaser.Game(config);
