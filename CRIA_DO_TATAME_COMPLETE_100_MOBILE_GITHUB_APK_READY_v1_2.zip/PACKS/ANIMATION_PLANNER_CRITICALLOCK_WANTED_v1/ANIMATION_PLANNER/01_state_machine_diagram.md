# State Machine — Combate + Critical Lock + Lesão + Procurado (Modo A)

## Estados principais (combate)
- STAND
- CLINCH
- TAKEDOWN (transitório)
- GROUND (posições: GUARD/HALF/SIDE/MOUNT/BACK/ASHI)
- SUBMISSION (minigame)
- CRITICAL_LOCK (modal de decisão)
- TAP_OUT (fim por finalização)
- KO_TKO (somente rota MMA)
- END (resultado + rewards/penalties)

## Gatilhos
### Para SUBMISSION
- Em GROUND ou CLINCH, ação SUB aplicada com sucesso → SUBMISSION(minigame)

### Para CRITICAL_LOCK
- SUBMISSION: `lockMeter >= 0.95` E `cameraRisk == true` OU `ruleSet.allowCritical == true`
- Pausa momentânea (0.3s), abre modal SOLTAR/SEGURAR

### Resultados CRITICAL_LOCK
- SOLTAR:
  - Sai para GROUND (posição mantém)
  - Honra + (pequeno)
  - Wanted - (pequeno ou nenhum)
- SEGURAR:
  - Se defensor não escapar em janela curta (0.4–0.8s):
    - aplica LESÃO (Braço / severidade 1–3)
    - Wanted + (dependendo de público/câmera)
    - Heat +, dinheiro + (underground)
  - Se defensor escapar:
    - Exaustão atacante + (stamina -)
    - posição pode inverter (risco)

## Procurado (Wanted 0–5)
Wanted não é “estado de combate”; é *estado de mundo*.
- aumenta por:
  - briga de rua (local público)
  - lesão grave em evento com público/câmera
  - Heat alto em evento grande
- efeitos:
  - bloqueios em eventos oficiais
  - inspeções/checagens em hubs
  - missões para reduzir (low profile, seminário, advogado, vitórias limpas)
