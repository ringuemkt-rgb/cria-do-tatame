# Sprite Frame Breakdown (produção)

## Resolução / Grid
- Personagem: 32×48 (pivot no pé)
- VFX: 64×64
- UI: 9-slice (painéis) + ícones 64×64
- Direções: N/S/E/W (exploração); combate pode usar 2 direções (E/W) para reduzir custo, mas manter 4 é melhor.

## Convenções de export (Aseprite)
- Tags por animação
- Export JSON array + PNG
- Trim OFF (mantém grid)
- Frame duration em ms (no JSON) ou FPS no Phaser

## Nomenclatura (chaves)
- char: `combat_stance_S`, `pass_knee_slice`, `sub_armbar_apply`, etc.
- vfx: `vfx_dust_puff`, `vfx_flash_score`, `vfx_critical_vignette`
- ui: `ui_modal_open`, `ui_star_ping`, `ui_injury_pulse`

## Checklist de legibilidade (mobile)
- Silhueta clara (2 tons de contraste)
- “Top/Bottom” indicado com sombra/offset + ícone TOP/BOT
- No Critical Lock: foco no modal (fundo escurece + vinheta)
