# Mobile Feedback (perfeito no celular)

## Haptics (Vibração)
- Queda: `haptic_light`
- Pontuação: `haptic_light`
- Critical Lock abrir: `haptic_light`
- SEGURAR bem-sucedido (lesão): `haptic_medium`
- Vitória/Derrota: `haptic_light` sequência 2x

## Camera / Screen shake (leve)
- Queda impacto: shake 60ms amplitude baixa
- Crank (segurar): shake 90ms amplitude média

## Acessibilidade
- opção “reduzir tremor”
- opção “desligar haptic”
- textos grandes no HUD (mínimo 12px em 384×216 base)

## Performance
- VFX em bursts curtos; não rodar partículas contínuas
- UI modal é DOM overlay OU Phaser UI (preferir Phaser para consistência)
