# Wanted — Reações do Mundo (estilo GTA, mas Punch Club)

## Objetivo
O mundo responde sem precisar de perseguição 3D:
- NPCs mudam diálogo/animação
- checkpoints em portas
- “sirene distante” em níveis altos
- eventos oficiais bloqueiam

## Camadas visuais (por nível)
★1 Comentado
- NPC “aponta/fofoca” (loop curto)
- UI: estrela 1 acende com `ui_star_ping`

★2 Observado
- NPC “olhar desconfiado” (idle alternativo)
- banner “checagem” na entrada do ginásio

★3 Notificado
- NPC “segurança” na porta (sprite)
- VFX: `vfx_siren_glow` sutil na borda da tela (loop lento)

★4 Procurado
- “abordagem” (cutscene rápida):
  - `npc_block` + `ui_dialog_police`
- UI: estrelas piscam levemente (warning)

★5 Caçado/Suspenso
- bloqueio de torneio oficial por X dias
- cutscene: aviso + missão “limpar nome”
- sem combate na rua em áreas públicas (só em arenas específicas)

## Animações NPC mínimas
- `npc_gossip_loop` (8f)
- `npc_guard_idle` (6f loop)
- `npc_guard_block` (6f)
- `npc_police_notice` (8f)  (sem armas; postura/rádio/gesto)

## UI mínima
- `ui_wanted_star_fill_1..5` (já no sheet)
- `ui_wanted_warning_pulse` (8f loop)
