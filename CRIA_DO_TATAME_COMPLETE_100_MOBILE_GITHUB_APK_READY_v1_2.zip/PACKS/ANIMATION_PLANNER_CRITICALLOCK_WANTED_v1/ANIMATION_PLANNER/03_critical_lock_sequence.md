# Sequência de Animação — Critical Lock (Armbar/Kimura)

## Objetivo de feeling (18+)
Sem sangue. Peso vem de:
- pausa dramática
- respiração/heartbeat
- vinheta + tremor leve
- consequência no HUD (lesão + estrelas)

## Timeline (ms) — recomendado
1) `sub_*_apply` (600–900ms)
2) entra `sub_*_squeeze_loop` (loop 8f @12fps)
3) ao atingir 95% lock:
   - `vfx_critical_vignette` ON (loop)
   - `sfx_heartbeat` ON
   - freeze input 120ms
   - abrir `ui_modal_critical_open` (240ms)
4) escolha:
   - SOLTAR:
     - `ui_modal_close` (200ms)
     - `vfx_release_spark` (6f)
     - retorna para GROUND
   - SEGURAR:
     - executar `sub_*_crank` (8–12f @14fps, non-loop)
     - janela de defesa curta 400–800ms:
       - se DEFENDER: `sub_escape` (12f) e volta para GROUND (pode inverter)
       - se FALHAR: aplica lesão e dispara:
         - `ui_injury_pulse` (8f)
         - `ui_star_ping` (quando wanted sobe)
         - `vfx_joint_snap` (sem gore; apenas flash/linha/poeira)
         - `sfx_snap_muffled` (curto)
         - `haptic_medium` (1 pulso)

## Animations (mínimo necessário)
### Para Armbar
- `sub_armbar_apply` (12f)
- `sub_armbar_squeeze_loop` (8f loop)
- `sub_armbar_crank` (10f)
- `sub_escape_generic` (12f)
- `tap_out` (10f)

### Para Kimura
- `sub_kimura_apply` (12f)
- `sub_kimura_squeeze_loop` (8f loop)
- `sub_kimura_crank` (10f)
- `sub_escape_generic` (12f)

## VFX/UI
- `vfx_critical_vignette` (8f loop)
- `vfx_flash_impact` (6f)
- `ui_modal_critical_open` (6f)
- `ui_modal_critical_idle` (loop)
- `ui_modal_critical_close` (6f)
- `ui_injury_pulse` (8f)
- `ui_star_ping` (6f)
