# Integração no Phaser (rápida e segura)

## 1) Assets esperados
- `assets/player_combat.png` (spritesheet 32×48)
- `assets/vfx.png` (spritesheet 64×64)
- `assets/ui_fx.png` (spritesheet 64×64)
- `assets/anims/animations_config.json`
- `assets/anims/fx_config.json`

## 2) Carregar spritesheets
```js
this.load.spritesheet('player_combat','assets/player_combat.png',{frameWidth:32, frameHeight:48});
this.load.spritesheet('vfx','assets/vfx.png',{frameWidth:64, frameHeight:64});
this.load.spritesheet('ui_fx','assets/ui_fx.png',{frameWidth:64, frameHeight:64});
```

## 3) Criar animações (auto-loader)
Use o `anim_autoloader.js` (pack anterior) ou crie um loader para `animations_config.json`.
A estrutura é igual: start/end/fps/loop.

## 4) Rodar FX triggers
Carregue `fx_config.json` e faça um dispatcher:
- `triggerFx('critical_lock_open')`
- `triggerFx('critical_lock_hold_success')`
- `triggerFx('wanted_level_up')`

Pseudo:
```js
function triggerFx(key){
  const fx = FX[key];
  fx.vfx?.forEach(k=>spawnVfx(k));
  fx.ui?.forEach(k=>playUiFx(k));
  if(fx.haptic) Haptics.pulse(fx.haptic);
  if(fx.cameraShake) cam.shake(fx.cameraShake.ms, ampToNumber(fx.cameraShake.amp));
}
```

## 5) Onde chamar (lógica)
- Quando lockMeter >= 0.95: `triggerFx('critical_lock_open')`
- Se SOLTAR: `triggerFx('critical_lock_release')`
- Se SEGURAR e falha defesa: `triggerFx('critical_lock_hold_success')`
- Quando Wanted aumenta: `triggerFx('wanted_level_up')`
