# Lesões — Feedback Visual (sem gore)

## Objetivo
O jogador precisa SENTIR a lesão:
- HUD pisca no ícone
- penalidade aparece como tooltip curto
- animação de “dor” do personagem (bem sutil)

## Animações (player)
- `hurt_flinch` (6f) — micro recuo
- `limp_arm_idle` (6f loop) — braço “segurado”
- `limp_arm_walk` (8f loop) — exploração com braço travado (opcional)

## UI/VFX
- `ui_injury_pulse` (8f) — contorno piscando
- `ui_debuff_toast` (ex: “BRAÇO S2: -25% FORÇA”)
- `vfx_pain_spark` (6f) — faísca/linha (sem sangue)

## Regras
- severidade S1/S2/S3 define intensidade do pulso e duração do toast
- em S3: bloquear algumas técnicas de braço (UI desativa card)
