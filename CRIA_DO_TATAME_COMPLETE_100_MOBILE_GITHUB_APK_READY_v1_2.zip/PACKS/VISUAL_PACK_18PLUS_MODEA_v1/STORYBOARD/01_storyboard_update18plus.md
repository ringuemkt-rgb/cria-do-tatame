# Storyboard Visual — Update 18+ (Lesões + Procurado)

Este storyboard define exatamente quais telas/imagens precisam existir no jogo.

## Telas obrigatórias (UI)
1) `Combat HUD (Oficial)` com:
   - Vida, Stamina, Flow
   - Posição atual + TOP/BOT
   - Pontos + estabilização (3s)
   - Indicador de Lesão (se houver)
   - Indicador de Procurado (estrelas)

2) `Combat HUD (Underground — Areia)` com:
   - Dominância (ticks)
   - Facção ativa (banner + emblema)
   - Procurado (estrelas)
   - Hint de Critical Lock

3) `Critical Lock Modal` com:
   - SOLTAR / SEGURAR
   - Consequências textuais

4) `Status Procurado`:
   - estrelas 0–5
   - efeitos e como reduzir

5) `Status Lesões`:
   - lista de lesões ativas
   - severidade, penalidade, tempo restante

6) `Celular` (GTA feel):
   - agenda/convites
   - mensagens
   - aba facções

## VFX/Feedback
- Poeira (quedas na areia)
- Flash de pontuação
- Vinheta/heartbeat no Critical Lock
- Vibração (haptic) em queda e Critical Lock
