# Prompts (opcionais) para gerar artes PIXEL PREMIUM no mesmo padrão do jogo

Use estes prompts em qualquer gerador de imagem (pixel art).

## 01 — Tela de luta oficial (Gi)
"pixel art game screenshot, top-down 3/4 camera, Brazilian jiu-jitsu match on tatami, two fighters in gi, elegant premium pixel art, crisp UI HUD with health bars, stamina bar, flow bar, position indicator (Guard/Half/Side/Mount/Back), score box, wanted stars indicator (2/5), injury indicator (arm injury), subtle grid on tatami, 16-bit inspired but modern pixel shading, high readability for mobile landscape, 384x216 base resolution"

## 02 — Luta underground na areia (No-Gi)
"premium pixel art screenshot, top-down 3/4, no-gi grappling fight on sand arena at night, crowd silhouettes, faction banner 'Os Aleluiados' with gold emblem, dominance meter ticks, wanted stars indicator (3/5), critical lock hint, dust particles, cinematic lighting, mobile-friendly UI, 384x216 base"

## 03 — Modal Critical Lock
"pixel art UI modal overlay, dark translucent background, bold title 'CRITICAL LOCK!', two buttons SOLTAR (green) and SEGURAR (red), consequence text, premium game UI design, mobile landscape"

## 04 — Tela de status Procurado
"pixel art UI screen, wanted level stars 0-5, Portuguese labels, clean modern pixel UI, list of effects and how to reduce wanted, premium HUD style"

## 05 — Celular no jogo
"pixel art smartphone UI, agenda, messages, factions tabs, three event cards, Portuguese text, premium pixel UI, GTA-inspired feel, not realistic photo"
