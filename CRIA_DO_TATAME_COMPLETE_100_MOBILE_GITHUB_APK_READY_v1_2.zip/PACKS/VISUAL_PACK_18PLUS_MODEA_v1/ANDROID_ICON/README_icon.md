# Ícone do APK / Android (guideline)

Recomendação:
- ícone 1024x1024 (PNG) para fonte
- gerar mipmaps: mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi
- manter fundo simples (Ink) e símbolo claro (Paper/Gold)
- evitar texto no ícone

Se estiver usando Capacitor/Android:
- colocar em `android/app/src/main/res/mipmap-*/ic_launcher.png`
- atualizar `AndroidManifest.xml` se necessário
