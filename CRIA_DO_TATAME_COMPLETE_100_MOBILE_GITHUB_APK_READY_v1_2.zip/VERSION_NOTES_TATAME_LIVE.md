# Version Notes — Tatame Live Pack v1

Data: 2026-02-20

## Incluído
- Sistema Tatame Live (rede social interna) com bancos:
  - 240 posts
  - 600 comentários
  - 4 patrocinadores (regras)
  - regras de algoritmo (engajamento/viral)
- GitHub Actions workflow para gerar APK debug por push/dispatch.
- Documentação de integração.

## Observação
Se o seu `index.html` não estiver servindo `web/src` via fetch, ajuste `banks_loader.js` para o caminho correto
ou mova os JSONs para `web/assets/social/` e atualize os fetches.
