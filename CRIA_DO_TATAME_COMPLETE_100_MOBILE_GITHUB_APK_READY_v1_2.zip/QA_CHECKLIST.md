# QA_CHECKLIST — Mobile Ready

## P0 (bloqueadores)
- [ ] Phaser local presente em `web/vendor/phaser.min.js` (>= 1MB)
- [ ] App abre offline (modo avião) sem tela branca
- [ ] Touch HUD funciona (mover + OK + VOLTA + A/B/C/D)
- [ ] Scale FIT (não corta / não estica)
- [ ] Botão VOLTAR do Android abre menu (não fecha app)

## P1 (qualidade)
- [ ] Save persiste após fechar e abrir
- [ ] 20 min de jogo sem crash
- [ ] Luta oficial: pontuação só após estabilizar
- [ ] Submundo: NO‑GI na areia
- [ ] Sem login/tela de autenticação

## P2 (polimento)
- [ ] Áudio não estoura (se assets existirem)
- [ ] Sem travamentos no HUD
- [ ] UI legível em 720p e 1080p


## v1.1 — Correções automáticas aplicadas
- CDN removido do index.html (Phaser local)
- SW sem entrada vazia e cache versionado
- Node scripts funcionando no GitHub (package.json type=module)
- build_verify verifica CDN e placeholder Phaser
