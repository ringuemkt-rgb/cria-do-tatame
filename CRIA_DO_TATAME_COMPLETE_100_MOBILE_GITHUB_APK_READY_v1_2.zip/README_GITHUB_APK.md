# CRIA DO TATAME — Build APK via GitHub (Debug)

## Como usar (passo a passo)
1. Crie um repositório no GitHub e suba **todo este conteúdo** (inclusive `.github/workflows`).
2. Vá em **Actions** → workflow **Android Debug APK** → **Run workflow**.
3. Ao finalizar, baixe o artefato: **cria-do-tatame-debug-apk** → `app-debug.apk`.

## Regras importantes
- O workflow baixa o Phaser para `web/vendor/phaser.min.js` via `npm run build:fetch-phaser`.
- O jogo fica **offline total** (sem CDN).
- Touch + scale FIT + sem login já vêm no pack.

## Onde entra o Tatame Live
Arquivos em: `web/src/social/`
- `social_engine.js` (núcleo)
- `posts_templates.json`, `comments_bank.json`, `sponsors.json`, `algorithm_rules.json`
- `banks_loader.js`

Integre chamando no boot (exemplo):
```js
import { SocialEngine } from "./src/social/social_engine.js";
import { JsonStorage } from "./src/social/storage.js";
import { loadTatameLiveBanks } from "./src/social/banks_loader.js";

const social = new SocialEngine(new JsonStorage());
await social.init(loadTatameLiveBanks);
social.generateDailyFeed(dayIndex, { honra, heat, wanted });
```
