# CRIA DO TATAME — COMPLETE PACK (Mobile + GitHub APK Ready)

Este ZIP já está **pronto para rodar** e **pronto para gerar APK pelo GitHub**.

## ✅ Jeito mais fácil (GitHub Actions → APK)
1) Crie um repositório no GitHub
2) Envie TODO o conteúdo deste ZIP (inclui `.github/workflows`)
3) Vá em **Actions** → **Android Debug APK** → **Run workflow**
4) Baixe o artifact: `cria-do-tatame-debug-apk` → `app-debug.apk`
5) Instale no Android (permitir “fontes desconhecidas”)

## ✅ Rodar local no PC (para testar no navegador)
1) Abra um terminal na pasta do projeto
2) Rode:
   - `node tools/build_agent/fetch_phaser.js`  (traz Phaser local → offline)
   - `node tools/build_agent/build_verify.js`  (valida checklist P0)
3) Abra `web/index.html` num servidor local (ex: Live Server / http-server)

## ✅ O que este pack garante (P0)
- Sem login (boot direto)
- Offline-first (sem CDN) após rodar o `fetch_phaser.js`
- Touch controls (D-pad + A/B/C/D + OK/VOLTA)
- Scale FIT + AutoCenter
- Service Worker desabilitado para APK (evita cache bug)
- Tatame Live (rede social estilo GTA) incluído em `web/src/social/`
- Packs extras incluídos em `/PACKS`:
  - Visual Pack (mockups/flags/icon sheet)
  - Animation Planner (state machine + JSON triggers)

## 📌 Observação
Os conteúdos de `/PACKS` são referência/planejamento e podem ser usados como assets finais ou placeholders.
