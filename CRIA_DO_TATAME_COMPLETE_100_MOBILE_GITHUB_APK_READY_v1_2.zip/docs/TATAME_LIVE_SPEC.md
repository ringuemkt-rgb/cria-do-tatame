# Tatame Live — Spec (GTA-like, Punch Club-friendly)

## Objetivo
- Rede social interna que afeta: Honra, Heat, Wanted, Patrocínio, Convites, Moral.
- Acesso pelo **celular** (HUD). Conteúdo curto e legível no mobile.

## Telas
1) Feed (posts)
2) Stories (cartões rápidos)
3) Inbox (mensagens/convites)
4) Sponsors (propostas/contratos)
5) News/Podcast (manchetes, comentários)

## Integração mínima (para jogo rodar já)
- No boot: `SocialEngine.init(loadTatameLiveBanks)`
- Por dia: `generateDailyFeed(dayIndex, vars)`
- Após luta: `processFightResult(vars, result)`
- Save: `engine.save()`

## Variáveis de entrada `vars`
- honra (0..100)
- heat (0..100)
- wanted (0..5)
- injuries (lista)
- titles (contador)
